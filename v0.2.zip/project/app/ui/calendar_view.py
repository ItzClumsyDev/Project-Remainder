"""
Calendar view — monthly calendar navigation and reminder manager.

Features:
  • Dynamic year range: [current_year - 2, current_year + 2] (never hardcoded)
  • Month and year navigation bounded cleanly to the dynamic range
  • 'Today' button to return to the current date instantly
  • Visual indicators for 'Today' and dates with scheduled reminders
  • Selected date panel showing all reminders with time, title, notes, and status
  • Add, Edit, and Delete reminder actions with validation
  • Visual consistency with Project Remainder's active theme
"""
from __future__ import annotations

import calendar
import tkinter as tk
from datetime import date, datetime
from tkinter import messagebox
from typing import TYPE_CHECKING, Callable

from .theme import (
    ACCENT, ACCENT_HV, BG, BORDER, CARD, CARD_HOVER, CARD_SEL, DANGER,
    FONT_BODY, FONT_BODY_B, FONT_H1, FONT_H2, FONT_H3, FONT_SMALL,
    FONT_TINY, PAD, PAD_LG, PAD_SM, SURFACE, TEXT, TEXT_HINT, TEXT_MUT,
    WARN, SUCCESS,
)
from .widgets import btn, card, sep

if TYPE_CHECKING:
    from ..core.reminder_manager import ReminderManager


class CalendarView(tk.Frame):
    """Monthly calendar and reminders UI."""

    def __init__(
        self,
        parent: tk.Widget,
        reminder_mgr: "ReminderManager",
    ) -> None:
        super().__init__(parent, bg=BG)
        self._mgr = reminder_mgr

        # Date states
        today = date.today()
        self._current_year = today.year
        self._nav_year = today.year
        self._nav_month = today.month
        self._selected_date = today.isoformat()  # YYYY-MM-DD

        # Register manager listener to re-render reminders
        self._mgr.add_change_listener(self._on_data_changed)

        self._day_widgets: list[tk.Widget] = []
        self._build()

    # ------------------------------------------------------------------
    # Dynamic year range helpers
    # ------------------------------------------------------------------

    @property
    def min_year(self) -> int:
        """2 years before the current year."""
        return date.today().year - 2

    @property
    def max_year(self) -> int:
        """2 years after the current year."""
        return date.today().year + 2

    # ------------------------------------------------------------------
    # Main Layout
    # ------------------------------------------------------------------

    def _build(self) -> None:
        # Header
        top_bar = tk.Frame(self, bg=BG, padx=PAD_LG, pady=PAD_LG)
        top_bar.pack(fill="x")

        tk.Label(top_bar, text="Calendar & Reminders", font=FONT_H1, bg=BG, fg=TEXT).pack(side="left")

        range_text = f"Allowed Range: {self.min_year} – {self.max_year}"
        tk.Label(top_bar, text=range_text, font=FONT_SMALL, bg=BG, fg=TEXT_MUT).pack(side="right", pady=(6, 0))

        # Content split container (Left: Calendar, Right: Reminders)
        split = tk.Frame(self, bg=BG, padx=PAD_LG)
        split.pack(fill="both", expand=True, pady=(0, PAD_LG))
        split.columnconfigure(0, weight=3)
        split.columnconfigure(1, weight=2)
        split.rowconfigure(0, weight=1)

        # ── Left: Calendar Matrix ─────────────────────────────────────
        cal_container = card(split, padx=PAD, pady=PAD)
        cal_container.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        self._build_calendar_panel(cal_container)

        # ── Right: Selected Date Reminders ────────────────────────────
        reminders_container = card(split, padx=PAD, pady=PAD)
        reminders_container.grid(row=0, column=1, sticky="nsew", padx=(10, 0))

        self._build_reminders_panel(reminders_container)

    # ------------------------------------------------------------------
    # Calendar Matrix Panel
    # ------------------------------------------------------------------

    def _build_calendar_panel(self, parent: tk.Frame) -> None:
        # Navigation bar
        nav_row = tk.Frame(parent, bg=CARD)
        nav_row.pack(fill="x", pady=(0, PAD))

        self._btn_prev_yr = btn(nav_row, "« Year", command=self._prev_year, style="ghost", padx=8, pady=4)
        self._btn_prev_yr.pack(side="left", padx=(0, 4))

        self._btn_prev_mo = btn(nav_row, "‹ Month", command=self._prev_month, style="ghost", padx=8, pady=4)
        self._btn_prev_mo.pack(side="left", padx=(0, 12))

        self._month_year_lbl = tk.Label(
            nav_row,
            text="",
            font=FONT_H2,
            bg=CARD,
            fg=TEXT,
            anchor="center",
        )
        self._month_year_lbl.pack(side="left", expand=True)

        btn(nav_row, "Today", command=self._go_today, style="secondary", padx=10, pady=4).pack(side="right", padx=(8, 0))

        self._btn_next_yr = btn(nav_row, "Year »", command=self._next_year, style="ghost", padx=8, pady=4)
        self._btn_next_yr.pack(side="right", padx=(4, 0))

        self._btn_next_mo = btn(nav_row, "Month ›", command=self._next_month, style="ghost", padx=8, pady=4)
        self._btn_next_mo.pack(side="right", padx=(0, 4))

        sep(parent, bg=BORDER).pack(fill="x", pady=(0, 8))

        # Day of week header
        dow_row = tk.Frame(parent, bg=CARD)
        dow_row.pack(fill="x", pady=(0, 4))
        for col_idx, d_name in enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]):
            dow_row.columnconfigure(col_idx, weight=1)
            color = WARN if col_idx >= 5 else TEXT_MUT
            tk.Label(
                dow_row,
                text=d_name,
                font=FONT_BODY_B,
                bg=CARD,
                fg=color,
                pady=4,
            ).grid(row=0, column=col_idx, sticky="nsew")

        # Grid frame for day cells
        self._days_grid = tk.Frame(parent, bg=CARD)
        self._days_grid.pack(fill="both", expand=True)
        for i in range(7):
            self._days_grid.columnconfigure(i, weight=1)
        for r in range(6):
            self._days_grid.rowconfigure(r, weight=1)

        self._render_month_grid()

    def _render_month_grid(self) -> None:
        # Clear existing cells
        for w in self._days_grid.winfo_children():
            w.destroy()

        month_name = calendar.month_name[self._nav_month]
        self._month_year_lbl.configure(text=f"{month_name} {self._nav_year}")

        # Update navigation buttons enabled/disabled states based on dynamic boundaries
        at_min_mo = (self._nav_year == self.min_year and self._nav_month == 1)
        at_max_mo = (self._nav_year == self.max_year and self._nav_month == 12)
        at_min_yr = (self._nav_year <= self.min_year)
        at_max_yr = (self._nav_year >= self.max_year)

        self._btn_prev_mo.configure(state="disabled" if at_min_mo else "normal")
        self._btn_next_mo.configure(state="disabled" if at_max_mo else "normal")
        self._btn_prev_yr.configure(state="disabled" if at_min_yr else "normal")
        self._btn_next_yr.configure(state="disabled" if at_max_yr else "normal")

        # Dates with reminders for badge indicators
        dates_with_reminders = self._mgr.get_dates_with_reminders()
        today_str = date.today().isoformat()

        cal = calendar.Calendar(firstweekday=0)
        weeks = cal.monthdayscalendar(self._nav_year, self._nav_month)

        for row_idx, week in enumerate(weeks):
            for col_idx, day_num in enumerate(week):
                if day_num == 0:
                    # Empty filler slot
                    empty = tk.Frame(self._days_grid, bg=CARD)
                    empty.grid(row=row_idx, column=col_idx, sticky="nsew", padx=2, pady=2)
                    continue

                date_iso = f"{self._nav_year:04d}-{self._nav_month:02d}-{day_num:02d}"
                is_selected = (date_iso == self._selected_date)
                is_today = (date_iso == today_str)
                has_reminders = (date_iso in dates_with_reminders)

                # Cell appearance
                if is_selected:
                    cell_bg = ACCENT
                    fg_day = TEXT
                elif is_today:
                    cell_bg = CARD_SEL
                    fg_day = TEXT
                else:
                    cell_bg = SURFACE
                    fg_day = TEXT

                cell = tk.Frame(self._days_grid, bg=cell_bg, cursor="hand2", relief="flat", bd=0)
                cell.grid(row=row_idx, column=col_idx, sticky="nsew", padx=2, pady=2)

                # Top row: Day number
                top_r = tk.Frame(cell, bg=cell_bg)
                top_r.pack(fill="x", padx=4, pady=(4, 0))

                lbl_num = tk.Label(
                    top_r,
                    text=str(day_num),
                    font=FONT_BODY_B if (is_selected or is_today) else FONT_BODY,
                    bg=cell_bg,
                    fg=fg_day,
                )
                lbl_num.pack(side="left")

                if is_today and not is_selected:
                    today_tag = tk.Label(
                        top_r,
                        text="Today",
                        font=FONT_TINY,
                        bg=cell_bg,
                        fg=SUCCESS,
                    )
                    today_tag.pack(side="right")

                # Bottom row: Event indicator
                bot_r = tk.Frame(cell, bg=cell_bg)
                bot_r.pack(fill="x", padx=4, pady=(2, 4))

                if has_reminders:
                    rem_badge = tk.Label(
                        bot_r,
                        text="● Event",
                        font=FONT_TINY,
                        bg=cell_bg,
                        fg=TEXT if is_selected else WARN,
                    )
                    rem_badge.pack(side="left")
                else:
                    tk.Label(bot_r, text="", font=FONT_TINY, bg=cell_bg).pack(side="left")

                # Click binding for the whole cell
                for w in (cell, top_r, lbl_num, bot_r):
                    w.bind("<Button-1>", lambda e, d=date_iso: self._select_date(d))

    # ------------------------------------------------------------------
    # Selected Date Reminders Panel
    # ------------------------------------------------------------------

    def _build_reminders_panel(self, parent: tk.Frame) -> None:
        self._reminders_parent = parent

        # Date header
        self._selected_date_lbl = tk.Label(
            parent,
            text="",
            font=FONT_H2,
            bg=CARD,
            fg=TEXT,
            anchor="w",
        )
        self._selected_date_lbl.pack(fill="x", pady=(0, 2))

        self._reminders_sub_lbl = tk.Label(
            parent,
            text="Reminders",
            font=FONT_H3,
            bg=CARD,
            fg=TEXT_MUT,
            anchor="w",
        )
        self._reminders_sub_lbl.pack(fill="x", pady=(0, 8))

        sep(parent, bg=BORDER).pack(fill="x", pady=(0, 10))

        # Scrollable list for reminders
        self._list_canvas = tk.Canvas(parent, bg=CARD, highlightthickness=0)
        self._list_sb = tk.Scrollbar(parent, orient="vertical", command=self._list_canvas.yview)
        self._list_canvas.configure(yscrollcommand=self._list_sb.set)

        self._list_sb.pack(side="right", fill="y")
        self._list_canvas.pack(side="left", fill="both", expand=True)

        self._list_inner = tk.Frame(self._list_canvas, bg=CARD)
        self._win_id = self._list_canvas.create_window((0, 0), window=self._list_inner, anchor="nw")

        self._list_inner.bind("<Configure>", lambda _: self._list_canvas.configure(scrollregion=self._list_canvas.bbox("all")))
        self._list_canvas.bind("<Configure>", lambda e: self._list_canvas.itemconfig(self._win_id, width=e.width))

        # Add reminder button pinned at bottom
        self._btn_add_reminder = btn(
            parent,
            "+ Add Reminder",
            command=self._open_add_dialog,
            style="primary",
        )

        self._render_reminders_list()

    def _render_reminders_list(self) -> None:
        # Update header
        try:
            d_obj = datetime.strptime(self._selected_date, "%Y-%m-%d").date()
            is_today = (d_obj == date.today())
            date_str = d_obj.strftime("%B %d, %Y")
            if is_today:
                header_text = f"Today — {date_str}"
            else:
                header_text = date_str
        except Exception:
            header_text = self._selected_date

        self._selected_date_lbl.configure(text=header_text)

        # Clear existing list items
        for w in self._list_inner.winfo_children():
            w.destroy()

        reminders = self._mgr.get_for_date(self._selected_date)

        if not reminders:
            empty_frame = tk.Frame(self._list_inner, bg=CARD, pady=30)
            empty_frame.pack(fill="x", expand=True)
            tk.Label(
                empty_frame,
                text="🗓 No reminders scheduled for this date.",
                font=FONT_BODY,
                bg=CARD,
                fg=TEXT_MUT,
            ).pack(pady=(0, 6))
            tk.Label(
                empty_frame,
                text="Click '+ Add Reminder' below to set one.",
                font=FONT_SMALL,
                bg=CARD,
                fg=TEXT_HINT,
            ).pack()
        else:
            for r in reminders:
                self._build_reminder_card(self._list_inner, r)

        # Repack Add button at the bottom of the right panel
        self._btn_add_reminder.pack_forget()
        self._btn_add_reminder.pack(fill="x", pady=(10, 0), side="bottom")

    def _build_reminder_card(self, parent: tk.Frame, reminder: dict) -> None:
        c = tk.Frame(parent, bg=SURFACE, padx=12, pady=10, relief="flat")
        c.pack(fill="x", pady=(0, 8))

        # Top row: Time and Notification badge
        top_row = tk.Frame(c, bg=SURFACE)
        top_row.pack(fill="x", pady=(0, 4))

        time_display = reminder.get("time_display") or reminder.get("time", "")
        time_lbl = tk.Label(
            top_row,
            text=f"⏰ {time_display}",
            font=FONT_BODY_B,
            bg=SURFACE,
            fg=ACCENT,
        )
        time_lbl.pack(side="left")

        # Notification status indicator
        if reminder.get("notified"):
            status_text = "✓ Notified"
            status_color = SUCCESS
        elif reminder.get("notify", True):
            status_text = "🔔 Alarm On"
            status_color = WARN
        else:
            status_text = "🔕 Muted"
            status_color = TEXT_MUT

        tk.Label(
            top_row,
            text=status_text,
            font=FONT_TINY,
            bg=SURFACE,
            fg=status_color,
        ).pack(side="right")

        # Title
        title_lbl = tk.Label(
            c,
            text=reminder.get("title", ""),
            font=FONT_BODY_B,
            bg=SURFACE,
            fg=TEXT,
            anchor="w",
            wraplength=260,
            justify="left",
        )
        title_lbl.pack(fill="x", pady=(0, 4))

        # Optional Notes
        notes = reminder.get("notes", "").strip()
        if notes:
            notes_lbl = tk.Label(
                c,
                text=notes,
                font=FONT_SMALL,
                bg=SURFACE,
                fg=TEXT_MUT,
                anchor="w",
                wraplength=260,
                justify="left",
            )
            notes_lbl.pack(fill="x", pady=(0, 8))

        # Action buttons row: Edit & Delete
        btn_row = tk.Frame(c, bg=SURFACE)
        btn_row.pack(fill="x", pady=(4, 0))

        btn(
            btn_row,
            "Edit",
            command=lambda r=reminder: self._open_edit_dialog(r),
            style="ghost",
            padx=10,
            pady=2,
        ).pack(side="left", padx=(0, 6))

        btn(
            btn_row,
            "Delete",
            command=lambda r_id=reminder["id"]: self._delete_reminder(r_id),
            style="danger",
            padx=10,
            pady=2,
        ).pack(side="left")

    # ------------------------------------------------------------------
    # User Actions & Navigation
    # ------------------------------------------------------------------

    def _select_date(self, date_iso: str) -> None:
        self._selected_date = date_iso
        self._render_month_grid()
        self._render_reminders_list()

    def select_date(self, date_iso: str) -> None:
        """Public API to navigate to and select a given date (YYYY-MM-DD)."""
        try:
            d = datetime.strptime(date_iso, "%Y-%m-%d").date()
            if self.min_year <= d.year <= self.max_year:
                self._nav_year = d.year
                self._nav_month = d.month
                self._select_date(date_iso)
        except Exception:
            pass

    def _prev_month(self) -> None:
        if self._nav_month > 1:
            self._nav_month -= 1
        elif self._nav_year > self.min_year:
            self._nav_year -= 1
            self._nav_month = 12
        self._render_month_grid()

    def _next_month(self) -> None:
        if self._nav_month < 12:
            self._nav_month += 1
        elif self._nav_year < self.max_year:
            self._nav_year += 1
            self._nav_month = 1
        self._render_month_grid()

    def _prev_year(self) -> None:
        if self._nav_year > self.min_year:
            self._nav_year -= 1
            self._render_month_grid()

    def _next_year(self) -> None:
        if self._nav_year < self.max_year:
            self._nav_year += 1
            self._render_month_grid()

    def _go_today(self) -> None:
        today = date.today()
        self._nav_year = today.year
        self._nav_month = today.month
        self._selected_date = today.isoformat()
        self._render_month_grid()
        self._render_reminders_list()

    def _delete_reminder(self, reminder_id: str) -> None:
        confirmed = messagebox.askyesno(
            "Delete Reminder",
            "Are you sure you want to delete this reminder?",
            parent=self,
        )
        if confirmed:
            self._mgr.delete_reminder(reminder_id)
            self._render_month_grid()
            self._render_reminders_list()

    def _on_data_changed(self) -> None:
        """Callback invoked when ReminderManager changes."""
        try:
            if self.winfo_exists():
                self._render_month_grid()
                self._render_reminders_list()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Dialogs: Add & Edit
    # ------------------------------------------------------------------

    def _open_add_dialog(self) -> None:
        now = datetime.now()
        # Suggest current time or nearest hour
        default_time = f"{now.hour % 12 or 12}:00 {'PM' if now.hour >= 12 else 'AM'}"
        ReminderDialog(
            self,
            title="Add Reminder",
            initial_date=self._selected_date,
            initial_time=default_time,
            on_save=self._on_save_add,
        )

    def _open_edit_dialog(self, reminder: dict) -> None:
        ReminderDialog(
            self,
            title="Edit Reminder",
            initial_title=reminder.get("title", ""),
            initial_date=reminder.get("date", self._selected_date),
            initial_time=reminder.get("time_display") or reminder.get("time", "7:00 PM"),
            initial_notes=reminder.get("notes", ""),
            initial_notify=reminder.get("notify", True),
            on_save=lambda t, d, tm, n, ntf: self._on_save_edit(reminder["id"], t, d, tm, n, ntf),
        )

    def _on_save_add(self, title: str, date_str: str, time_str: str, notes: str, notify: bool) -> None:
        self._mgr.add_reminder(title, date_str, time_str, notes, notify)
        self._selected_date = date_str
        self._render_month_grid()
        self._render_reminders_list()

    def _on_save_edit(self, reminder_id: str, title: str, date_str: str, time_str: str, notes: str, notify: bool) -> None:
        self._mgr.update_reminder(reminder_id, title, date_str, time_str, notes, notify)
        self._selected_date = date_str
        self._render_month_grid()
        self._render_reminders_list()


# ---------------------------------------------------------------------------
# Reminder Add/Edit Dialog
# ---------------------------------------------------------------------------

class ReminderDialog(tk.Toplevel):
    """Modal dialog for creating and editing a reminder."""

    def __init__(
        self,
        parent: tk.Widget,
        title: str,
        initial_title: str = "",
        initial_date: str = "",
        initial_time: str = "7:00 PM",
        initial_notes: str = "",
        initial_notify: bool = True,
        on_save: Callable[[str, str, str, str, bool], None] | None = None,
    ) -> None:
        super().__init__(parent)
        self._on_save = on_save

        self.title(title)
        self.configure(bg=CARD)
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        # Center relative to parent
        self.geometry("420x440")
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() - 420) // 2
            y = parent.winfo_rooty() + (parent.winfo_height() - 440) // 2
            self.geometry(f"+{max(10, x)}+{max(10, y)}")
        except Exception:
            pass

        p = tk.Frame(self, bg=CARD, padx=20, pady=20)
        p.pack(fill="both", expand=True)

        tk.Label(p, text=title, font=FONT_H2, bg=CARD, fg=TEXT).pack(anchor="w", pady=(0, 16))

        # Title entry
        tk.Label(p, text="Title *", font=FONT_BODY_B, bg=CARD, fg=TEXT).pack(anchor="w")
        self._title_var = tk.StringVar(value=initial_title)
        title_entry = tk.Entry(
            p,
            textvariable=self._title_var,
            font=FONT_BODY,
            bg=SURFACE,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
        )
        title_entry.pack(fill="x", ipady=6, pady=(4, 12))
        title_entry.focus_set()

        # Date & Time in a 2-column row
        dt_row = tk.Frame(p, bg=CARD)
        dt_row.pack(fill="x", pady=(0, 12))
        dt_row.columnconfigure(0, weight=1)
        dt_row.columnconfigure(1, weight=1)

        # Date
        d_col = tk.Frame(dt_row, bg=CARD)
        d_col.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        tk.Label(d_col, text="Date (YYYY-MM-DD)", font=FONT_BODY_B, bg=CARD, fg=TEXT).pack(anchor="w")
        self._date_var = tk.StringVar(value=initial_date)
        tk.Entry(
            d_col,
            textvariable=self._date_var,
            font=FONT_BODY,
            bg=SURFACE,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
        ).pack(fill="x", ipady=6, pady=(4, 0))

        # Time
        t_col = tk.Frame(dt_row, bg=CARD)
        t_col.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        tk.Label(t_col, text="Time (e.g. 7:00 PM)", font=FONT_BODY_B, bg=CARD, fg=TEXT).pack(anchor="w")
        self._time_var = tk.StringVar(value=initial_time)
        tk.Entry(
            t_col,
            textvariable=self._time_var,
            font=FONT_BODY,
            bg=SURFACE,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
        ).pack(fill="x", ipady=6, pady=(4, 0))

        # Notes
        tk.Label(p, text="Notes / Description (Optional)", font=FONT_BODY_B, bg=CARD, fg=TEXT).pack(anchor="w")
        self._notes_text = tk.Text(
            p,
            height=4,
            font=FONT_BODY,
            bg=SURFACE,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            wrap="word",
        )
        self._notes_text.insert("1.0", initial_notes)
        self._notes_text.pack(fill="x", pady=(4, 12))

        # Notification Checkbox
        self._notify_var = tk.BooleanVar(value=initial_notify)
        cb = tk.Checkbutton(
            p,
            text="🔔 Play sound & show notification when due",
            variable=self._notify_var,
            font=FONT_BODY,
            bg=CARD,
            fg=TEXT,
            selectcolor=SURFACE,
            activebackground=CARD,
            activeforeground=TEXT,
            relief="flat",
            cursor="hand2",
        )
        cb.pack(anchor="w", pady=(0, 16))

        # Action Buttons
        btn_bar = tk.Frame(p, bg=CARD)
        btn_bar.pack(fill="x", side="bottom")

        btn(btn_bar, "Save", command=self._save, style="primary", padx=20).pack(side="right")
        btn(btn_bar, "Cancel", command=self.destroy, style="ghost", padx=16).pack(side="right", padx=(0, 8))

    def _save(self) -> None:
        title = self._title_var.get().strip()
        date_str = self._date_var.get().strip()
        time_str = self._time_var.get().strip()
        notes = self._notes_text.get("1.0", "end-1c").strip()
        notify = self._notify_var.get()

        if not title:
            messagebox.showwarning("Validation", "Please enter a reminder title.", parent=self)
            return

        # Validate date format YYYY-MM-DD
        try:
            datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            messagebox.showwarning("Validation", "Date must be in YYYY-MM-DD format (e.g. 2026-09-20).", parent=self)
            return

        if self._on_save:
            self._on_save(title, date_str, time_str, notes, notify)

        self.destroy()
