"""
Settings view — user-configurable options.

Sections:
  • Timer defaults  (default duration)
  • Alarm Sound     (sound toggle, custom MP3/WAV selector, test sound)
  • To-Do list      (enable / disable toggle)
  • Data            (show data file location, open folder, open sessions.json)
  • About           (app info)
"""
from __future__ import annotations

import os
import subprocess
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox
from typing import TYPE_CHECKING, Callable

from ..core.audio_player import (
    get_sound_state, pause_sound, play_sound_file,
    play_test_sound, resume_sound, stop_sound,
)
from .theme import (
    ACCENT, BG, BORDER, CARD, CARD_HOVER, DANGER, FONT_BODY, FONT_BODY_B,
    FONT_H1, FONT_H2, FONT_H3, FONT_SMALL, FONT_TINY, PAD, PAD_LG,
    SURFACE, TEXT, TEXT_MUT,
)
from .widgets import btn, sep

if TYPE_CHECKING:
    from ..core.session_manager import SessionManager
    from ..core.settings_manager import SettingsManager

_DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"


class SettingsView(tk.Frame):
    """Settings view."""

    def __init__(
        self,
        parent: tk.Widget,
        settings_mgr: "SettingsManager",
        on_todo_toggled: Callable[[bool], None],
        on_timer_default_changed: Callable[[int], None],
        session_mgr: "SessionManager | None" = None,
        on_data_cleared: Callable[[], None] | None = None,
        on_theme_changed: Callable[[str], None] | None = None,
    ) -> None:
        super().__init__(parent, bg=BG)
        self._settings = settings_mgr
        self._session_mgr = session_mgr
        self._on_todo_toggled = on_todo_toggled
        self._on_timer_changed = on_timer_default_changed
        self._on_data_cleared = on_data_cleared
        self._on_theme_changed = on_theme_changed
        self._poll_timer_id: str | None = None
        self._pause_btn: tk.Button | None = None
        self._quote_status_lbl: tk.Label | None = None
        self._build()
        self._schedule_poll()

    # ------------------------------------------------------------------

    def _build(self) -> None:
        # Scrollable wrapper
        canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        sb = tk.Scrollbar(self, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=BG)
        win_id = canvas.create_window((0, 0), window=inner, anchor="nw")

        inner.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win_id, width=e.width))

        p = tk.Frame(inner, bg=BG, padx=PAD_LG, pady=PAD_LG)
        p.pack(fill="both", expand=True)

        tk.Label(p, text="Settings", font=FONT_H1, bg=BG, fg=TEXT).pack(anchor="w", pady=(0, 20))

        # ── Theme ─────────────────────────────────────────────────────
        self._section(p, "Theme")

        theme_card = tk.Frame(p, bg=CARD, padx=16, pady=14)
        theme_card.pack(fill="x", pady=(0, 4))

        tk.Label(
            theme_card,
            text="Interface Appearance",
            font=FONT_BODY_B,
            bg=CARD,
            fg=TEXT,
        ).pack(anchor="w", pady=(0, 10))

        self._theme_var = tk.StringVar(value=self._settings.get("theme", "clumsy"))

        themes_options = [
            ("light", "Light", "A normal light interface with crisp contrast."),
            ("dark", "Dark", "A dark interface designed to be comfortable in low-light environments."),
            ("clumsy", "Clumsy", "Original default Project Remainder appearance (Forest Green & Dark)."),
        ]

        for val, title, desc in themes_options:
            t_row = tk.Frame(theme_card, bg=CARD)
            t_row.pack(fill="x", pady=4)

            rb = tk.Radiobutton(
                t_row,
                text=f"{title} Mode",
                value=val,
                variable=self._theme_var,
                command=lambda v=val: self._select_theme(v),
                font=FONT_BODY_B,
                bg=CARD,
                fg=TEXT,
                selectcolor=SURFACE,
                activebackground=CARD,
                activeforeground=TEXT,
                relief="flat",
                cursor="hand2",
            )
            rb.pack(anchor="w")

            tk.Label(
                t_row,
                text=desc,
                font=FONT_SMALL,
                bg=CARD,
                fg=TEXT_MUT,
            ).pack(anchor="w", padx=(24, 0))

        tk.Label(
            p,
            text="Theme updates the entire application immediately and persists across restarts.",
            font=FONT_SMALL,
            bg=BG,
            fg=TEXT_MUT,
        ).pack(anchor="w", pady=(2, 16))

        # ── Timer defaults ────────────────────────────────────────────
        self._section(p, "Timer")

        row = tk.Frame(p, bg=CARD, padx=16, pady=14)
        row.pack(fill="x", pady=(0, 4))

        tk.Label(row, text="Default duration (minutes)",
                 font=FONT_BODY, bg=CARD, fg=TEXT).pack(side="left")

        self._timer_var = tk.StringVar(
            value=str(self._settings.get("default_timer_minutes", 25))
        )
        entry = tk.Entry(
            row,
            textvariable=self._timer_var,
            font=FONT_BODY,
            bg=SURFACE,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            bd=0,
            width=5,
            justify="center",
        )
        entry.pack(side="right", ipady=6, ipadx=4)
        entry.bind("<FocusOut>", lambda _: self._save_timer_default())
        entry.bind("<Return>",   lambda _: self._save_timer_default())

        tk.Label(p,
                 text="This duration is pre-selected on the Timer screen.",
                 font=FONT_SMALL, bg=BG, fg=TEXT_MUT).pack(anchor="w", pady=(2, 16))

        # ── Notifications & Alarm Sound ───────────────────────────────
        self._section(p, "Notifications & Alarm Sound")

        sound_card = tk.Frame(p, bg=CARD, padx=16, pady=14)
        sound_card.pack(fill="x", pady=(0, 4))

        # Toggle row
        toggle_row = tk.Frame(sound_card, bg=CARD)
        toggle_row.pack(fill="x", pady=(0, 10))

        tk.Label(toggle_row, text="Play sound when timer finishes",
                 font=FONT_BODY, bg=CARD, fg=TEXT).pack(side="left")

        self._sound_var = tk.BooleanVar(value=self._settings.get("sound_enabled", True))
        toggle = tk.Checkbutton(
            toggle_row,
            variable=self._sound_var,
            bg=CARD,
            activebackground=CARD,
            selectcolor=SURFACE,
            relief="flat",
            cursor="hand2",
            command=self._save_sound,
        )
        toggle.pack(side="right")

        sep(sound_card, bg=BORDER).pack(fill="x", pady=(0, 10))

        # Custom MP3 File Selector
        tk.Label(sound_card, text="Alarm Sound File (MP3 / WAV)",
                 font=FONT_BODY_B, bg=CARD, fg=TEXT).pack(anchor="w")

        self._sound_path_var = tk.StringVar(value=self._settings.get("custom_sound_path", ""))
        self._sound_lbl = tk.Label(
            sound_card,
            text=self._get_sound_display_name(),
            font=FONT_SMALL,
            bg=CARD,
            fg=ACCENT if self._sound_path_var.get() else TEXT_MUT,
            anchor="w",
            wraplength=480,
            justify="left",
        )
        self._sound_lbl.pack(anchor="w", pady=(4, 10))

        sound_btn_row = tk.Frame(sound_card, bg=CARD)
        sound_btn_row.pack(anchor="w")

        btn(sound_btn_row, "Choose MP3/WAV...", command=self._choose_sound_file, style="secondary").pack(side="left", padx=(0, 8))
        btn(sound_btn_row, "▶ Test Music", command=self._test_music, style="ghost").pack(side="left", padx=(0, 8))
        self._pause_btn = btn(sound_btn_row, "⏸ Pause", command=self._toggle_pause_resume, style="ghost")
        self._pause_btn.pack(side="left", padx=(0, 8))
        btn(sound_btn_row, "Reset to Default", command=self._reset_sound_to_default, style="ghost").pack(side="left")

        self._update_pause_resume_btn()

        tk.Label(p,
                 text="You can select any MP3 or WAV audio file from your computer.",
                 font=FONT_SMALL, bg=BG, fg=TEXT_MUT).pack(anchor="w", pady=(2, 16))

        # ── Motivational Quote ───────────────────────────────────────
        self._section(p, "Motivational Quote")

        quote_card = tk.Frame(p, bg=CARD, padx=16, pady=14)
        quote_card.pack(fill="x", pady=(0, 4))

        tk.Label(
            quote_card,
            text="Session Review Quote",
            font=FONT_BODY_B,
            bg=CARD,
            fg=TEXT,
        ).pack(anchor="w")

        tk.Label(
            quote_card,
            text="This quote is displayed at the end of every completed session.",
            font=FONT_SMALL,
            bg=CARD,
            fg=TEXT_MUT,
        ).pack(anchor="w", pady=(2, 10))

        quote_input_row = tk.Frame(quote_card, bg=CARD)
        quote_input_row.pack(fill="x", pady=(0, 10))

        current_quote = self._settings.get("motivational_quote", "Small progress is still progress.")
        self._quote_var = tk.StringVar(value=current_quote)

        quote_entry = tk.Entry(
            quote_input_row,
            textvariable=self._quote_var,
            font=FONT_BODY,
            bg=SURFACE,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            bd=0,
        )
        quote_entry.pack(side="left", fill="x", expand=True, ipady=7, ipadx=8)
        quote_entry.bind("<Return>", lambda _: self._save_quote())

        quote_btn_row = tk.Frame(quote_card, bg=CARD)
        quote_btn_row.pack(anchor="w")

        btn(quote_btn_row, "Save Quote", command=self._save_quote, style="primary").pack(side="left", padx=(0, 8))
        btn(quote_btn_row, "Reset to Default", command=self._reset_quote, style="ghost").pack(side="left", padx=(0, 8))

        self._quote_status_lbl = tk.Label(
            quote_btn_row,
            text="",
            font=FONT_SMALL,
            bg=CARD,
            fg=ACCENT,
        )
        self._quote_status_lbl.pack(side="left", padx=(4, 0))

        tk.Label(
            p,
            text="Keep it inspiring to help you reflect and stay consistent.",
            font=FONT_SMALL,
            bg=BG,
            fg=TEXT_MUT,
        ).pack(anchor="w", pady=(2, 16))

        # ── To-Do list ────────────────────────────────────────────────
        self._section(p, "To-Do List")

        todo_row = tk.Frame(p, bg=CARD, padx=16, pady=14)
        todo_row.pack(fill="x", pady=(0, 4))

        tk.Label(todo_row, text="Enable To-Do List",
                 font=FONT_BODY_B, bg=CARD, fg=TEXT).pack(side="left")

        self._todo_var = tk.BooleanVar(value=self._settings.get("todo_enabled", True))
        todo_toggle = tk.Checkbutton(
            todo_row,
            variable=self._todo_var,
            bg=CARD,
            activebackground=CARD,
            selectcolor=SURFACE,
            relief="flat",
            cursor="hand2",
            command=self._toggle_todo,
        )
        todo_toggle.pack(side="right")

        tk.Label(p,
                 text="When disabled, the To-Do tab is hidden and tasks are not shown\n"
                      "during session review. Your existing tasks are preserved.",
                 font=FONT_SMALL, bg=BG, fg=TEXT_MUT, justify="left").pack(anchor="w", pady=(2, 16))

        # ── Save & Data Management ────────────────────────────────────
        self._section(p, "Save & Data Management")

        data_card = tk.Frame(p, bg=CARD, padx=16, pady=14)
        data_card.pack(fill="x", pady=(0, 4))

        tk.Label(data_card, text="Local Data Storage",
                 font=FONT_BODY_B, bg=CARD, fg=TEXT).pack(anchor="w")
        tk.Label(data_card, text=str(_DATA_DIR),
                 font=FONT_SMALL, bg=CARD, fg=TEXT_MUT, anchor="w").pack(anchor="w", pady=(4, 8))

        btn_row = tk.Frame(data_card, bg=CARD)
        btn_row.pack(anchor="w", pady=(0, 14))

        btn(btn_row, "Open Folder", command=self._open_data_folder, style="secondary").pack(side="left", padx=(0, 8))
        btn(btn_row, "Open sessions.json", command=self._open_sessions_file, style="ghost").pack(side="left")

        sep(data_card, bg=BORDER).pack(fill="x", pady=(0, 14))

        tk.Label(data_card, text="Delete Save Data",
                 font=FONT_BODY_B, bg=CARD, fg=DANGER).pack(anchor="w")
        tk.Label(data_card,
                 text="Permanently delete all stored session history and statistics.\n"
                      "Your motivational quote, settings, audio preferences, and to-do list will not be affected.",
                 font=FONT_SMALL, bg=CARD, fg=TEXT_MUT, justify="left").pack(anchor="w", pady=(2, 10))

        delete_btn_row = tk.Frame(data_card, bg=CARD)
        delete_btn_row.pack(anchor="w")

        btn(delete_btn_row, "🗑 Delete Save Data", command=self._confirm_delete_save_data, style="danger").pack(side="left")

        tk.Label(p,
                 text="All data is stored locally. No cloud, no accounts.",
                 font=FONT_SMALL, bg=BG, fg=TEXT_MUT).pack(anchor="w", pady=(2, 16))

        # ── About ─────────────────────────────────────────────────────
        self._section(p, "About")

        about_card = tk.Frame(p, bg=CARD, padx=16, pady=14)
        about_card.pack(fill="x")

        info = [
            ("Project Remainder", ACCENT, FONT_H3),
            ("Version 1.0.0  ·  Open Source  ·  MIT License", TEXT_MUT, FONT_SMALL),
            ("A lightweight work-session timer and productivity tracker.", TEXT_MUT, FONT_SMALL),
            ("Built with Python + tkinter. Zero external dependencies.", TEXT_MUT, FONT_SMALL),
        ]
        for text, color, font in info:
            tk.Label(about_card, text=text, font=font, bg=CARD, fg=color).pack(anchor="w", pady=1)

    # ------------------------------------------------------------------

    def _section(self, parent: tk.Frame, title: str) -> None:
        tk.Label(parent, text=title, font=FONT_H3, bg=BG, fg=TEXT).pack(anchor="w", pady=(4, 6))

    def _get_sound_display_name(self) -> str:
        path = self._settings.get("custom_sound_path", "")
        if path and Path(path).exists():
            return f"Selected: {Path(path).name} ({path})"
        return "Default (System Notification Beep)"

    def _choose_sound_file(self) -> None:
        file_path = filedialog.askopenfilename(
            title="Select Alarm Sound",
            filetypes=[
                ("Audio Files (*.mp3;*.wav;*.m4a;*.wma)", "*.mp3;*.wav;*.m4a;*.wma"),
                ("MP3 Audio (*.mp3)", "*.mp3"),
                ("WAV Audio (*.wav)", "*.wav"),
                ("All Files (*.*)", "*.*"),
            ],
            parent=self,
        )
        if file_path:
            stop_sound()
            self._settings.set("custom_sound_path", file_path)
            self._sound_path_var.set(file_path)
            self._sound_lbl.configure(
                text=f"Selected: {Path(file_path).name} ({file_path})",
                fg=ACCENT,
            )
            # Preview the sound
            play_test_sound(file_path)
            self._update_pause_resume_btn()

    def _test_music(self) -> None:
        custom_sound = self._settings.get("custom_sound_path", "")
        play_test_sound(custom_sound if custom_sound else None)
        self._update_pause_resume_btn()

    def _toggle_pause_resume(self) -> None:
        state = get_sound_state()
        if state == "playing":
            pause_sound()
        elif state == "paused":
            resume_sound()
        self._update_pause_resume_btn()

    def _update_pause_resume_btn(self) -> None:
        if self._pause_btn is None:
            return
        try:
            if not self.winfo_exists():
                return
            state = get_sound_state()
            if state == "playing":
                self._pause_btn.configure(text="⏸ Pause", state="normal")
            elif state == "paused":
                self._pause_btn.configure(text="▶ Resume", state="normal")
            else:
                self._pause_btn.configure(text="⏸ Pause", state="disabled")
        except Exception:
            pass

    def _schedule_poll(self) -> None:
        try:
            if not self.winfo_exists():
                return
            self._update_pause_resume_btn()
            self._poll_timer_id = self.after(500, self._schedule_poll)
        except Exception:
            pass

    def _reset_sound_to_default(self) -> None:
        stop_sound()
        self._settings.set("custom_sound_path", "")
        self._sound_path_var.set("")
        self._sound_lbl.configure(
            text="Default (System Notification Beep)",
            fg=TEXT_MUT,
        )
        self._update_pause_resume_btn()

    def destroy(self) -> None:
        if self._poll_timer_id is not None:
            try:
                self.after_cancel(self._poll_timer_id)
            except Exception:
                pass
            self._poll_timer_id = None
        super().destroy()

    def _save_timer_default(self) -> None:
        try:
            mins = int(float(self._timer_var.get().strip()))
            if mins < 1:
                raise ValueError
            self._settings.set("default_timer_minutes", mins)
            self._on_timer_changed(mins)
        except ValueError:
            self._timer_var.set(str(self._settings.get("default_timer_minutes", 25)))

    def _save_sound(self) -> None:
        self._settings.set("sound_enabled", self._sound_var.get())

    def _toggle_todo(self) -> None:
        enabled = self._todo_var.get()
        self._settings.set("todo_enabled", enabled)
        self._on_todo_toggled(enabled)

    def _open_data_folder(self) -> None:
        _DATA_DIR.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(_DATA_DIR))
        except Exception:
            try:
                subprocess.Popen(["explorer.exe", str(_DATA_DIR)])
            except Exception:
                pass

    def _open_sessions_file(self) -> None:
        _DATA_DIR.mkdir(parents=True, exist_ok=True)
        sessions_path = _DATA_DIR / "sessions.json"
        if not sessions_path.exists():
            try:
                with sessions_path.open("w", encoding="utf-8") as f:
                    f.write('{\n  "sessions": []\n}\n')
            except OSError:
                pass

        try:
            os.startfile(str(sessions_path))
        except OSError:
            # Fallback on Windows if no app is associated with .json
            try:
                subprocess.Popen(["notepad.exe", str(sessions_path)])
            except Exception:
                pass
        except Exception:
            pass

    def _save_quote(self) -> None:
        new_quote = self._quote_var.get().strip()
        if not new_quote:
            new_quote = "Small progress is still progress."
            self._quote_var.set(new_quote)
        self._settings.set("motivational_quote", new_quote)
        if self._quote_status_lbl:
            self._quote_status_lbl.configure(text="✓ Saved", fg=ACCENT)
            self.after(2500, self._clear_quote_status)

    def _reset_quote(self) -> None:
        default_quote = "Small progress is still progress."
        self._quote_var.set(default_quote)
        self._settings.set("motivational_quote", default_quote)
        if self._quote_status_lbl:
            self._quote_status_lbl.configure(text="✓ Reset to default", fg=ACCENT)
            self.after(2500, self._clear_quote_status)

    def _clear_quote_status(self) -> None:
        try:
            if self._quote_status_lbl and self._quote_status_lbl.winfo_exists():
                self._quote_status_lbl.configure(text="")
        except Exception:
            pass

    def _confirm_delete_save_data(self) -> None:
        """Prompt user with a confirmation dialog, then safely delete session history."""
        confirmed = messagebox.askyesno(
            "Delete Save Data",
            "Are you sure you want to delete all saved session data?\n\n"
            "• All completed session logs and statistics will be permanently removed.\n"
            "• This action cannot be undone.\n\n"
            "Note: Your motivational quote, app settings, audio preferences, and to-do list will NOT be deleted.\n\n"
            "Do you want to proceed?",
            icon="warning",
            parent=self,
        )
        if not confirmed:
            return

        if self._session_mgr is None:
            messagebox.showerror(
                "Error",
                "Session manager is unavailable. Cannot delete save data.",
                parent=self,
            )
            return

        try:
            self._session_mgr.delete_save_data()
            if self._on_data_cleared:
                self._on_data_cleared()
            messagebox.showinfo(
                "Save Data Deleted",
                "Your session history and statistics have been successfully cleared.\n\n"
                "All settings, motivational quote, and to-do list items were preserved.",
                parent=self,
            )
        except Exception as err:
            messagebox.showerror(
                "Deletion Failed",
                f"An error occurred while deleting save data:\n\n{err}",
                parent=self,
            )

    def _select_theme(self, theme_val: str) -> None:
        self._settings.set("theme", theme_val)
        if self._on_theme_changed:
            self._on_theme_changed(theme_val)

