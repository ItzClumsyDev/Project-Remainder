"""
Session-review overlay view (in-window).

Appears inside the existing main application window when a timer/stopwatch session finishes.
When a timer finishes:
  1. Alarm sound plays continuously.
  2. Review controls are blurred/disabled and non-interactive.
  3. A prominent "Turn Off Alarm" button is shown.
  4. Clicking "Turn Off Alarm" stops the alarm and unlocks the review controls.
"""
from __future__ import annotations

import time
import tkinter as tk
from tkinter import messagebox
from typing import TYPE_CHECKING, Callable

from ..core.audio_player import play_alarm, stop_sound
from .theme import (
    ACCENT, ACCENT_HV, BG, BORDER, CARD, CARD_HOVER, DANGER,
    FONT_BODY, FONT_BODY_B, FONT_H1, FONT_H2, FONT_H3,
    FONT_SMALL, FONT_TIMER_SM, SURFACE, TEXT, TEXT_MUT, WARN,
)
from .widgets import StarRating, btn, sep

if TYPE_CHECKING:
    from ..core.session_manager import SessionManager
    from ..core.settings_manager import SettingsManager
    from ..core.todo_manager import TodoManager


class OverlayWindow(tk.Frame):
    """
    In-window session-review dialog.
    Rendered on top of the main window views (zero secondary Toplevel windows).
    """

    def __init__(
        self,
        parent: tk.Widget,
        *,
        mode: str,
        elapsed: float,
        start_time: str,
        target: int | None,
        todo_enabled: bool,
        todo_manager: "TodoManager | None",
        session_mgr: "SessionManager",
        settings_mgr: "SettingsManager",
        on_done: Callable[[dict], None] | None = None,
        on_close: Callable[[], None] | None = None,
        alarm_active: bool = True,
    ) -> None:
        super().__init__(parent, bg=BG)
        self._parent = parent
        self._mode = mode
        self._elapsed = elapsed
        self._start_time = start_time
        self._target = target
        self._todo_enabled = todo_enabled
        self._todo_mgr = todo_manager
        self._session_mgr = session_mgr
        self._settings_mgr = settings_mgr
        self._on_done = on_done
        self._on_close = on_close
        self._alarm_active = alarm_active

        self._rating = 0
        self._task_vars: dict[str, tk.BooleanVar] = {}
        self._task_cbs: list[tk.Checkbutton] = []
        self._save_btn: tk.Button | None = None
        self._discard_btn: tk.Button | None = None
        self._blur_overlay: tk.Frame | None = None

        self._build()
        self.place(x=0, y=0, relwidth=1, relheight=1)
        self.tkraise()

        if self._alarm_active:
            self._play_alarm_sound()
            self._set_review_interactive(False)
            self._show_alarm_overlay()
        else:
            self._set_review_interactive(True)

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------

    def _build(self) -> None:
        # Centered container card
        self._card_box = tk.Frame(
            self,
            bg=CARD,
            highlightbackground=BORDER,
            highlightthickness=1,
            padx=28,
            pady=20,
        )
        self._card_box.place(relx=0.5, rely=0.5, anchor="center", width=560, height=600)

        # ── Header ───────────────────────────────────────────────────
        hdr = tk.Frame(self._card_box, bg=CARD)
        hdr.pack(fill="x", pady=(0, 10))

        emoji = "⏰" if self._mode == "timer" else "⏱"
        tk.Label(
            hdr,
            text=f"{emoji}  Session Complete!",
            font=FONT_H1,
            bg=CARD,
            fg=ACCENT,
        ).pack(anchor="w")

        # Duration summary
        from ..core.stats_engine import fmt_duration, fmt_clock
        dur_str = fmt_duration(self._elapsed)
        clock_str = fmt_clock(self._elapsed)
        mode_label = "Timer" if self._mode == "timer" else "Stopwatch"
        summary = f"{mode_label} · {clock_str}  ({dur_str})"
        if self._mode == "timer" and self._target:
            pct = min(100, int(self._elapsed / self._target * 100))
            summary += f"  ·  {pct}% of goal"

        tk.Label(
            hdr,
            text=summary,
            font=FONT_BODY,
            bg=CARD,
            fg=TEXT_MUT,
        ).pack(anchor="w", pady=(2, 0))

        sep(self._card_box, bg=BORDER).pack(fill="x", pady=(8, 10))

        # Scrollable content area
        canvas = tk.Canvas(self._card_box, bg=CARD, highlightthickness=0)
        scrollbar = tk.Scrollbar(self._card_box, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=CARD)
        canvas_window = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _on_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(canvas_window, width=event.width)

        inner.bind("<Configure>", _on_configure)
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(canvas_window, width=e.width))

        # Mouse wheel scrolling
        def _on_mousewheel(event):
            if not self._alarm_active:
                canvas.yview_scroll(-1 * (event.delta // 120), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        # ── Motivational Quote ───────────────────────────────────────
        raw_quote = self._settings_mgr.get("motivational_quote", "Small progress is still progress.")
        quote_text = str(raw_quote).strip() if raw_quote and str(raw_quote).strip() else "Small progress is still progress."

        quote_card = tk.Frame(
            inner,
            bg=SURFACE,
            highlightbackground=BORDER,
            highlightthickness=1,
            padx=16,
            pady=10,
        )
        quote_card.pack(fill="x", pady=(0, 10))

        tk.Label(
            quote_card,
            text=f'“{quote_text}”',
            font=("Segoe UI", 11, "italic"),
            bg=SURFACE,
            fg=ACCENT_HV,
            wraplength=460,
            justify="center",
        ).pack(fill="x")

        # ── Rating ───────────────────────────────────────────────────
        rating_card = tk.Frame(inner, bg=SURFACE, padx=14, pady=12)
        rating_card.pack(fill="x", pady=(0, 10))

        tk.Label(
            rating_card,
            text="How productive was this session?",
            font=FONT_H3,
            bg=SURFACE,
            fg=TEXT,
        ).pack(anchor="w")
        tk.Label(
            rating_card,
            text="Select a rating from 1 (low) to 5 (excellent).",
            font=FONT_SMALL,
            bg=SURFACE,
            fg=TEXT_MUT,
        ).pack(anchor="w", pady=(2, 8))

        self._star_widget = StarRating(
            rating_card,
            on_change=self._on_rating,
            bg=SURFACE,
        )
        self._star_widget.pack(anchor="w")

        self._rating_hint = tk.Label(
            rating_card,
            text="Tap a star to rate",
            font=FONT_SMALL,
            bg=SURFACE,
            fg=TEXT_MUT,
        )
        self._rating_hint.pack(anchor="w", pady=(4, 0))

        # ── Notes ────────────────────────────────────────────────────
        notes_card = tk.Frame(inner, bg=SURFACE, padx=14, pady=12)
        notes_card.pack(fill="x", pady=(0, 10))

        tk.Label(
            notes_card,
            text="What did you accomplish?",
            font=FONT_H3,
            bg=SURFACE,
            fg=TEXT,
        ).pack(anchor="w")
        tk.Label(
            notes_card,
            text="Optional — jot down what you worked on.",
            font=FONT_SMALL,
            bg=SURFACE,
            fg=TEXT_MUT,
        ).pack(anchor="w", pady=(2, 6))

        self._notes = tk.Text(
            notes_card,
            height=3,
            font=FONT_BODY,
            bg=CARD,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            bd=0,
            padx=8,
            pady=6,
            wrap="word",
        )
        self._notes.pack(fill="x")

        # ── Tasks ────────────────────────────────────────────────────
        if self._todo_enabled and self._todo_mgr:
            tasks = self._todo_mgr.get_incomplete()
            if tasks:
                tasks_card = tk.Frame(inner, bg=SURFACE, padx=14, pady=12)
                tasks_card.pack(fill="x", pady=(0, 10))

                tk.Label(
                    tasks_card,
                    text="Tasks completed this session?",
                    font=FONT_H3,
                    bg=SURFACE,
                    fg=TEXT,
                ).pack(anchor="w")
                tk.Label(
                    tasks_card,
                    text="Check any tasks you finished.",
                    font=FONT_SMALL,
                    bg=SURFACE,
                    fg=TEXT_MUT,
                ).pack(anchor="w", pady=(2, 6))

                for task in tasks:
                    tid = task["id"]
                    var = tk.BooleanVar(value=False)
                    self._task_vars[tid] = var
                    cb = tk.Checkbutton(
                        tasks_card,
                        text=task["text"],
                        variable=var,
                        font=FONT_BODY,
                        bg=SURFACE,
                        fg=TEXT,
                        selectcolor=CARD,
                        activebackground=SURFACE,
                        activeforeground=TEXT,
                        relief="flat",
                        anchor="w",
                        cursor="hand2",
                    )
                    cb.pack(fill="x", pady=1)
                    self._task_cbs.append(cb)

        # ── Action buttons ───────────────────────────────────────────
        sep(inner, bg=BORDER).pack(fill="x", pady=10)

        btn_row = tk.Frame(inner, bg=CARD)
        btn_row.pack(fill="x")

        self._discard_btn = btn(btn_row, "Discard", command=self._discard, style="ghost")
        self._discard_btn.pack(side="right", padx=(8, 0))

        self._save_btn = btn(btn_row, "Save Session", command=self._save, style="primary")
        self._save_btn.pack(side="right")

    # ------------------------------------------------------------------
    # Blur / Alarm Overlay
    # ------------------------------------------------------------------

    def _show_alarm_overlay(self) -> None:
        """Render a frosted/dimmed blur scrim with a prominent 'Turn Off Alarm' button."""
        if self._blur_overlay is not None:
            return

        self._blur_overlay = tk.Frame(
            self,
            bg="#090d12",
            cursor="arrow",
        )
        self._blur_overlay.place(x=0, y=0, relwidth=1, relheight=1)

        # Block any underlying clicks
        self._blur_overlay.bind("<Button-1>", lambda e: "break")

        alarm_box = tk.Frame(
            self._blur_overlay,
            bg=CARD,
            highlightbackground=ACCENT,
            highlightthickness=2,
            padx=32,
            pady=28,
        )
        alarm_box.place(relx=0.5, rely=0.5, anchor="center", width=480, height=270)

        tk.Label(
            alarm_box,
            text="⏰",
            font=("Segoe UI", 32),
            bg=CARD,
            fg=ACCENT,
        ).pack(pady=(0, 4))

        tk.Label(
            alarm_box,
            text="Timer Finished! Alarm Sounding",
            font=FONT_H1,
            bg=CARD,
            fg=TEXT,
        ).pack(pady=(0, 6))

        tk.Label(
            alarm_box,
            text="Turn off the alarm to unlock and complete your session review.",
            font=FONT_BODY,
            bg=CARD,
            fg=TEXT_MUT,
            wraplength=400,
            justify="center",
        ).pack(pady=(0, 18))

        turn_off_btn = btn(
            alarm_box,
            "🔔  Turn Off Alarm",
            command=self._turn_off_alarm,
            style="danger",
            padx=28,
            pady=12,
        )
        turn_off_btn.pack()
        turn_off_btn.focus_set()

        # Keyboard shortcuts to dismiss alarm
        alarm_box.bind_all("<Return>", self._on_key_turn_off)
        alarm_box.bind_all("<space>", self._on_key_turn_off)

    def _on_key_turn_off(self, event) -> None:
        if self._alarm_active:
            self._turn_off_alarm()

    def _turn_off_alarm(self) -> None:
        """Stop alarm, remove blur overlay, and unlock review controls."""
        stop_sound()
        self._alarm_active = False

        if self._blur_overlay:
            self._blur_overlay.destroy()
            self._blur_overlay = None

        self._set_review_interactive(True)
        try:
            self._notes.focus_set()
        except Exception:
            pass

    def _set_review_interactive(self, interactive: bool) -> None:
        """Enable or disable all review controls."""
        self._star_widget.set_enabled(interactive)

        self._notes.configure(
            state="normal" if interactive else "disabled",
            bg=CARD if interactive else "#12161f",
            fg=TEXT if interactive else TEXT_MUT,
        )

        for cb in self._task_cbs:
            cb.configure(
                state="normal" if interactive else "disabled",
                fg=TEXT if interactive else TEXT_MUT,
            )

        if self._save_btn:
            self._save_btn.configure(state="normal" if interactive else "disabled")
        if self._discard_btn:
            self._discard_btn.configure(state="normal" if interactive else "disabled")

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def _on_rating(self, value: int) -> None:
        if self._alarm_active:
            return
        self._rating = value
        labels = [
            "", "😕 Low productivity",
            "🙁 Below average",
            "😐 Average session",
            "🙂 Good session",
            "😄 Excellent session!",
        ]
        if 0 <= value < len(labels):
            self._rating_hint.configure(text=labels[value], fg=ACCENT)

    def _save(self) -> None:
        if self._alarm_active:
            return
        stop_sound()
        try:
            notes_text = self._notes.get("1.0", "end-1c").strip()
            completed_task_ids = [tid for tid, var in self._task_vars.items() if var.get()]
            rating = max(1, self._rating) if self._rating > 0 else 3

            end_time = time.strftime("%H:%M:%S")
            start_time = self._start_time or time.strftime("%H:%M:%S")

            session = self._session_mgr.save_session(
                mode=self._mode,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=self._elapsed,
                target_duration=self._target,
                productivity_rating=rating,
                notes=notes_text,
                tasks_completed=completed_task_ids,
            )

            # Mark completed tasks in the todo manager
            if self._todo_mgr:
                for tid in completed_task_ids:
                    self._todo_mgr.set_complete(tid, True)

            self.destroy()

            if self._on_done:
                self._on_done(session)
        except Exception as err:
            messagebox.showerror("Save Error", f"Failed to save session: {err}", parent=self)

    def _discard(self) -> None:
        stop_sound()
        self.destroy()

        if self._on_close:
            self._on_close()

    def _play_alarm_sound(self) -> None:
        play_alarm(self._settings_mgr)

    def destroy(self) -> None:
        try:
            self.unbind_all("<Return>")
            self.unbind_all("<space>")
            self.unbind_all("<MouseWheel>")
        except Exception:
            pass
        super().destroy()


