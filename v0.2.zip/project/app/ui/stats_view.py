"""
Statistics view — productivity history with charts and metric cards.

Sections:
  • Period selector  (Today / This Week / This Month / This Year)
  • Metric cards     (sessions, time, avg rating, best day, tasks)
  • Bar chart        (daily minutes worked, last 7 days)
  • Line chart       (daily avg productivity rating, last 7 days)
  • Session log      (scrollable list of sessions in the period)
"""
from __future__ import annotations

import tkinter as tk
from datetime import datetime
from typing import TYPE_CHECKING

from .theme import (
    ACCENT, BG, BORDER, CARD, FONT_BODY, FONT_BODY_B,
    FONT_H1, FONT_H2, FONT_H3, FONT_SMALL, FONT_TINY,
    PAD, PAD_LG, STAR_ON, SURFACE, TEXT, TEXT_MUT, WARN,
)
from .widgets import BarChart, LineChart, btn, sep

if TYPE_CHECKING:
    from ..core.session_manager import SessionManager


_PERIODS = [
    ("Last 1 Day",   "1day"),
    ("Last 7 Days",  "7days"),
    ("Last 1 Month", "1month"),
    ("Last 1 Year",  "1year"),
]


class StatsView(tk.Frame):
    """Statistics and history view."""

    def __init__(self, parent: tk.Widget, session_mgr: "SessionManager") -> None:
        super().__init__(parent, bg=BG)
        self._session_mgr = session_mgr
        self._period = "7days"
        self._period_btns: dict[str, tk.Button] = {}
        self._build()

    # ------------------------------------------------------------------

    def _build(self) -> None:
        # ── Period selector (fixed top bar) ──────────────────────────
        top_bar = tk.Frame(self, bg=SURFACE, padx=PAD_LG, pady=10)
        top_bar.pack(fill="x")

        tk.Label(top_bar, text="Statistics", font=FONT_H2, bg=SURFACE, fg=TEXT).pack(side="left")

        tab_row = tk.Frame(top_bar, bg=SURFACE)
        tab_row.pack(side="right")

        for label, key in _PERIODS:
            b = tk.Button(
                tab_row,
                text=label,
                font=FONT_SMALL,
                bg=ACCENT if key == self._period else CARD,
                fg=TEXT,
                activebackground=ACCENT,
                activeforeground=TEXT,
                relief="flat",
                bd=0,
                padx=12,
                pady=5,
                cursor="hand2",
                command=lambda k=key: self._switch_period(k),
            )
            b.pack(side="left", padx=3)
            self._period_btns[key] = b

        # ── Scrollable content ────────────────────────────────────────
        self._canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        sb = tk.Scrollbar(self, orient="vertical", command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)

        self._inner = tk.Frame(self._canvas, bg=BG)
        self._win_id = self._canvas.create_window((0, 0), window=self._inner, anchor="nw")

        self._inner.bind("<Configure>",
                         lambda _: self._canvas.configure(scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>",
                          lambda e: self._canvas.itemconfig(self._win_id, width=e.width))
        self._canvas.bind_all(
            "<MouseWheel>",
            lambda e: self._canvas.yview_scroll(-1 * (e.delta // 120), "units"),
        )

        self._render()

    # ------------------------------------------------------------------

    def _switch_period(self, period: str) -> None:
        self._period = period
        for k, b in self._period_btns.items():
            b.configure(bg=ACCENT if k == period else CARD)
        self._render()

    def _render(self) -> None:
        for w in self._inner.winfo_children():
            w.destroy()

        from ..core.stats_engine import (
            compute_stats, filter_sessions, fmt_duration,
            get_period_chart_data, readable_date,
        )

        all_s = self._session_mgr.get_all()
        period_s = filter_sessions(all_s, self._period)
        stats = compute_stats(period_s, period=self._period)

        p = tk.Frame(self._inner, bg=BG, padx=PAD_LG, pady=PAD_LG)
        p.pack(fill="both", expand=True)

        period_title_map = {
            "1day": "Last 1 Day",
            "today": "Last 1 Day",
            "7days": "Last 7 Days",
            "week": "Last 7 Days",
            "1month": "Last 1 Month",
            "month": "Last 1 Month",
            "1year": "Last 1 Year",
            "year": "Last 1 Year",
        }
        period_label = period_title_map.get(self._period, "Statistics")

        # ── Empty Data Handling ───────────────────────────────────────
        if not period_s:
            tk.Label(p, text=period_label, font=FONT_H1, bg=BG, fg=TEXT).pack(anchor="w")
            tk.Label(p, text="No sessions recorded during this period.",
                     font=FONT_BODY, bg=BG, fg=TEXT_MUT).pack(anchor="w", pady=(4, 20))

            empty_card = tk.Frame(p, bg=CARD, padx=32, pady=40)
            empty_card.pack(fill="x", pady=(0, 20))

            tk.Label(empty_card, text="📊", font=("Segoe UI", 36), bg=CARD, fg=TEXT_MUT).pack(pady=(0, 8))
            tk.Label(empty_card, text="No sessions recorded during this period.", font=FONT_H2, bg=CARD, fg=TEXT).pack(pady=(0, 6))
            tk.Label(
                empty_card,
                text="Complete a work session or select another time range above to view insights.",
                font=FONT_BODY, bg=CARD, fg=TEXT_MUT,
            ).pack()
            return

        # ── Summary headline ─────────────────────────────────────────
        headline_parts = []
        n = stats["total_sessions"]
        headline_parts.append(f"{n} session{'s' if n != 1 else ''}")
        headline_parts.append(fmt_duration(stats["total_seconds"]) + " worked")
        if stats["avg_rating"]:
            headline_parts.append(f"Avg rating {stats['avg_rating']}/5")

        if self._period in ("1year", "year"):
            if stats.get("most_productive_month"):
                headline_parts.append(f"Best month: {stats['most_productive_month']}")
        elif stats.get("most_productive_day"):
            headline_parts.append(f"Best day: {readable_date(stats['most_productive_day'])}")

        headline = "  ·  ".join(headline_parts)

        tk.Label(p, text=period_label, font=FONT_H1, bg=BG, fg=TEXT).pack(anchor="w")
        tk.Label(p, text=headline, font=FONT_BODY, bg=BG, fg=TEXT_MUT).pack(anchor="w", pady=(4, 16))

        # ── Metric cards tailored to period scale ─────────────────────
        grid = tk.Frame(p, bg=BG)
        grid.pack(fill="x", pady=(0, 20))
        grid.columnconfigure((0, 1, 2, 3, 4), weight=1, uniform="m")

        if self._period in ("1month", "month"):
            fourth_val = fmt_duration(stats["avg_seconds_per_day"]) + "/day"
            fourth_sub = "Avg work / day"
        elif self._period in ("1year", "year"):
            fourth_val = fmt_duration(stats["avg_seconds_per_month"]) + "/mo"
            fourth_sub = "Avg work / month"
        else:
            fourth_val = fmt_duration(stats["avg_duration_seconds"]) if stats["total_sessions"] else "—"
            fourth_sub = "Avg session"

        metrics = [
            (str(stats["total_sessions"]),         "Sessions",       TEXT),
            (fmt_duration(stats["total_seconds"]), "Total time",     ACCENT),
            (f"{stats['avg_rating']}/5" if stats["avg_rating"] else "—",
                                                   "Avg rating",     WARN),
            (fourth_val,                            fourth_sub,       TEXT),
            (str(stats["total_tasks_completed"]),  "Tasks done",     TEXT),
        ]

        for col, (val, sub, color) in enumerate(metrics):
            c = tk.Frame(grid, bg=CARD, padx=12, pady=12)
            c.grid(row=0, column=col, sticky="nsew", padx=(0 if col == 0 else 4, 0))
            tk.Label(c, text=val, font=FONT_H2, bg=CARD, fg=color).pack(anchor="w")
            tk.Label(c, text=sub, font=FONT_TINY, bg=CARD, fg=TEXT_MUT).pack(anchor="w")

        # ── Charts ───────────────────────────────────────────────────
        chart_data = get_period_chart_data(self._period, period_s)

        # Bar chart
        tk.Label(p, text=chart_data["bar_title"],
                 font=FONT_H3, bg=BG, fg=TEXT).pack(anchor="w", pady=(0, 6))
        bar = BarChart(p, height=160, bg=CARD)
        bar.pack(fill="x", pady=(0, 20))
        bar.set_data(chart_data["bar_data"])

        # Line chart
        tk.Label(p, text=chart_data["line_title"],
                 font=FONT_H3, bg=BG, fg=TEXT).pack(anchor="w", pady=(0, 6))
        line = LineChart(p, height=130, bg=CARD)
        line.pack(fill="x", pady=(0, 20))
        line.set_data(chart_data["line_data"], max_y=chart_data.get("max_y", 5.0))

        # ── Session log ───────────────────────────────────────────────
        tk.Label(p, text="Sessions in this period",
                 font=FONT_H3, bg=BG, fg=TEXT).pack(anchor="w", pady=(0, 8))
        for s in reversed(period_s):
            self._session_row(p, s)

    def _session_row(self, parent: tk.Frame, s: dict) -> None:
        from ..core.stats_engine import fmt_duration, readable_date

        row = tk.Frame(parent, bg=CARD, padx=14, pady=10)
        row.pack(fill="x", pady=(0, 3))

        left = tk.Frame(row, bg=CARD)
        left.pack(side="left", fill="x", expand=True)

        dur = fmt_duration(s.get("duration_seconds", 0))
        mode = s.get("mode", "?").capitalize()
        start = s.get("start_time", "")
        notes = s.get("notes") or "No notes"
        if len(notes) > 70:
            notes = notes[:67] + "…"

        tk.Label(left,
                 text=f"{readable_date(s.get('date',''))}  {start}  ·  {dur}  ({mode})",
                 font=FONT_BODY_B, bg=CARD, fg=TEXT).pack(anchor="w")
        tk.Label(left, text=notes, font=FONT_SMALL, bg=CARD, fg=TEXT_MUT).pack(anchor="w", pady=(1, 0))

        # Stars
        rating = s.get("productivity_rating", 0)
        if rating:
            stars = "★" * rating + "☆" * (5 - rating)
            tk.Label(row, text=stars, font=("Segoe UI", 10), bg=CARD, fg=STAR_ON).pack(side="right")

    def refresh(self) -> None:
        """Re-render after new session saved."""
        self._render()
