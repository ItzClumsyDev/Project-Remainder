"""
Project Remainder — visual design constants and theme system.

Supports three theme modes:
  • Clumsy (Default): Forest green brand color with calm dark GitHub aesthetic
  • Dark: Neutral, low-light optimized dark interface with soft blue accent
  • Light: Crisp, clean light interface with high contrast and blue accent

Typography: Segoe UI (Windows built-in, excellent legibility)
"""
from __future__ import annotations

import sys
from typing import Any

# ── Theme Palettes ──────────────────────────────────────────────────────────
THEMES: dict[str, dict[str, str]] = {
    "clumsy": {
        "BG":         "#0d1117",   # Main window background
        "SURFACE":    "#161b22",   # Sidebar / secondary panels
        "CARD":       "#21262d",   # Card / widget backgrounds
        "CARD_HOVER": "#2d333b",   # Card hover state
        "CARD_SEL":   "#1f3a1f",   # Selected card (green tint)
        "ACCENT":     "#228822",   # Primary brand green
        "ACCENT_HV":  "#2da52d",   # Accent on hover
        "ACCENT_DIM": "#1a6b1a",   # Dimmed accent (button inactive)
        "TEXT":       "#e6edf3",   # Primary text
        "TEXT_MUT":   "#7d8590",   # Muted / label text
        "TEXT_HINT":  "#484f58",   # Very muted hint text
        "BORDER":     "#30363d",   # Borders and separators
        "BORDER_LT":  "#3d444d",   # Light border (inputs)
        "WARN":       "#d29922",   # Warning / amber
        "DANGER":     "#f85149",   # Error / red
        "SUCCESS":    "#3fb950",   # Success / bright green
        "RING_BG":    "#21262d",
        "RING_FG":    "#228822",
        "RING_WARN":  "#d29922",
        "RING_CRIT":  "#f85149",
        "STAR_ON":    "#d29922",
        "STAR_OFF":   "#30363d",
        "CHART_FILL": "#1a3a1a",
    },
    "dark": {
        "BG":         "#121212",   # Main window background
        "SURFACE":    "#1e1e1e",   # Sidebar / secondary panels
        "CARD":       "#252525",   # Card / widget backgrounds
        "CARD_HOVER": "#2f2f2f",   # Card hover state
        "CARD_SEL":   "#1e3a5f",   # Selected card (blue tint)
        "ACCENT":     "#3b82f6",   # Soothing calm blue accent
        "ACCENT_HV":  "#60a5fa",   # Accent on hover
        "ACCENT_DIM": "#1d4ed8",   # Dimmed accent
        "TEXT":       "#f3f4f6",   # Primary high-contrast light text
        "TEXT_MUT":   "#9ca3af",   # Muted text
        "TEXT_HINT":  "#6b7280",   # Very muted hint text
        "BORDER":     "#333333",   # Clean low-light borders
        "BORDER_LT":  "#444444",   # Input borders
        "WARN":       "#f59e0b",   # Amber warning
        "DANGER":     "#ef4444",   # Red error
        "SUCCESS":    "#10b981",   # Emerald success
        "RING_BG":    "#2a2a2a",
        "RING_FG":    "#3b82f6",
        "RING_WARN":  "#f59e0b",
        "RING_CRIT":  "#ef4444",
        "STAR_ON":    "#f59e0b",
        "STAR_OFF":   "#374151",
        "CHART_FILL": "#1e293b",
    },
    "light": {
        "BG":         "#f6f8fa",   # Main window background (soft off-white)
        "SURFACE":    "#ffffff",   # Sidebar / secondary panels (crisp white)
        "CARD":       "#ffffff",   # Card / widget backgrounds
        "CARD_HOVER": "#f0f3f6",   # Card hover state
        "CARD_SEL":   "#ddf4ff",   # Selected card (light blue tint)
        "ACCENT":     "#0969da",   # Primary clean blue
        "ACCENT_HV":  "#0854b0",   # Accent on hover
        "ACCENT_DIM": "#54aeff",   # Dimmed accent
        "TEXT":       "#1f2328",   # Primary dark text
        "TEXT_MUT":   "#656d76",   # Muted / label text
        "TEXT_HINT":  "#8c959f",   # Very muted hint text
        "BORDER":     "#d0d7de",   # Borders and separators
        "BORDER_LT":  "#e1e4e8",   # Light border (inputs)
        "WARN":       "#bf8700",   # Warning / amber
        "DANGER":     "#cf222e",   # Error / red
        "SUCCESS":    "#1a7f37",   # Success / green
        "RING_BG":    "#e1e4e8",
        "RING_FG":    "#0969da",
        "RING_WARN":  "#bf8700",
        "RING_CRIT":  "#cf222e",
        "STAR_ON":    "#e3b341",
        "STAR_OFF":   "#d0d7de",
        "CHART_FILL": "#dbeafe",
    },
}

CURRENT_THEME = "clumsy"

# Initialize default palette variables (clumsy)
BG          = THEMES["clumsy"]["BG"]
SURFACE     = THEMES["clumsy"]["SURFACE"]
CARD        = THEMES["clumsy"]["CARD"]
CARD_HOVER  = THEMES["clumsy"]["CARD_HOVER"]
CARD_SEL    = THEMES["clumsy"]["CARD_SEL"]
ACCENT      = THEMES["clumsy"]["ACCENT"]
ACCENT_HV   = THEMES["clumsy"]["ACCENT_HV"]
ACCENT_DIM  = THEMES["clumsy"]["ACCENT_DIM"]
TEXT        = THEMES["clumsy"]["TEXT"]
TEXT_MUT    = THEMES["clumsy"]["TEXT_MUT"]
TEXT_HINT   = THEMES["clumsy"]["TEXT_HINT"]
BORDER      = THEMES["clumsy"]["BORDER"]
BORDER_LT   = THEMES["clumsy"]["BORDER_LT"]
WARN        = THEMES["clumsy"]["WARN"]
DANGER      = THEMES["clumsy"]["DANGER"]
SUCCESS     = THEMES["clumsy"]["SUCCESS"]

RING_BG     = THEMES["clumsy"]["RING_BG"]
RING_FG     = THEMES["clumsy"]["RING_FG"]
RING_WARN   = THEMES["clumsy"]["RING_WARN"]
RING_CRIT   = THEMES["clumsy"]["RING_CRIT"]

STAR_ON     = THEMES["clumsy"]["STAR_ON"]
STAR_OFF    = THEMES["clumsy"]["STAR_OFF"]
CHART_FILL  = THEMES["clumsy"]["CHART_FILL"]


def set_theme(name: str) -> None:
    """
    Switch the active theme. Updates module-level color constants in this module
    as well as all imported namespaces in app.ui.*.
    """
    global CURRENT_THEME, BG, SURFACE, CARD, CARD_HOVER, CARD_SEL
    global ACCENT, ACCENT_HV, ACCENT_DIM, TEXT, TEXT_MUT, TEXT_HINT
    global BORDER, BORDER_LT, WARN, DANGER, SUCCESS
    global RING_BG, RING_FG, RING_WARN, RING_CRIT, STAR_ON, STAR_OFF, CHART_FILL

    if name not in THEMES:
        name = "clumsy"

    CURRENT_THEME = name
    palette = THEMES[name]

    # Update this module's globals
    for key, val in palette.items():
        globals()[key] = val

    # Synchronize any loaded app.ui modules that imported theme variables directly
    for mod_name, mod in list(sys.modules.items()):
        if mod and (mod_name.startswith("app.ui") or mod_name.startswith("ui")):
            for key, val in palette.items():
                if hasattr(mod, key):
                    setattr(mod, key, val)


def get_current_theme() -> str:
    """Return the name of the currently active theme ('clumsy', 'dark', or 'light')."""
    return CURRENT_THEME


def get_theme_palette(name: str | None = None) -> dict[str, str]:
    """Return dictionary of color definitions for the specified or current theme."""
    target = name if name in THEMES else CURRENT_THEME
    return dict(THEMES[target])


# ── Font definitions (Segoe UI — ships with Windows) ───────────────────────
_F = "Segoe UI"
_M = "Courier New"

FONT_H1         = (_F, 20, "bold")
FONT_H2         = (_F, 15, "bold")
FONT_H3         = (_F, 12, "bold")
FONT_BODY       = (_F, 11)
FONT_BODY_B     = (_F, 11, "bold")
FONT_SMALL      = (_F, 9)
FONT_TINY       = (_F, 8)
FONT_MONO       = (_M, 11)

FONT_TIMER_XL   = (_F, 54, "bold")
FONT_TIMER_LG   = (_F, 40, "bold")
FONT_TIMER_MD   = (_F, 28, "bold")
FONT_TIMER_SM   = (_F, 18, "bold")

# ── Layout metrics ─────────────────────────────────────────────────────────
SIDEBAR_W   = 190    # px, fixed sidebar width
PAD         = 12     # standard padding
PAD_LG      = 20     # large padding
PAD_SM      = 6      # small padding
BTN_H       = 38     # button height
RADIUS      = 6      # corner radius for drawn elements
