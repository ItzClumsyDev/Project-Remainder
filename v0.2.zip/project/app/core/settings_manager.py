"""
Settings manager — reads and writes application settings to JSON.
Handles corruption gracefully by falling back to defaults.
Uses atomic file replacement to prevent data loss.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

# Resolve path: app/core/ → app/ → ProjectRemainder/ → data/
_DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"

DEFAULT_SETTINGS: dict[str, Any] = {
    "default_timer_minutes": 25,
    "todo_enabled": True,
    "sound_enabled": True,
    "custom_sound_path": "",
    "window_geometry": "960x680+80+60",
    # Session recovery: written when a session starts, cleared when it ends
    "active_session": None,
    "motivational_quote": "Small progress is still progress.",
    "theme": "clumsy",
}


class SettingsManager:
    """Persists and retrieves application-wide settings."""

    def __init__(self) -> None:
        _DATA_DIR.mkdir(parents=True, exist_ok=True)
        self._path = _DATA_DIR / "settings.json"
        self._data: dict[str, Any] = self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self._data[key] = value
        self._write()

    def update(self, mapping: dict[str, Any]) -> None:
        self._data.update(mapping)
        self._write()

    def all(self) -> dict[str, Any]:
        return dict(self._data)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> dict[str, Any]:
        try:
            if self._path.exists():
                with self._path.open("r", encoding="utf-8") as f:
                    saved = json.load(f)
                    if isinstance(saved, dict):
                        return {**DEFAULT_SETTINGS, **saved}
        except (json.JSONDecodeError, OSError, ValueError):
            pass
        return dict(DEFAULT_SETTINGS)

    def _write(self) -> None:
        try:
            _DATA_DIR.mkdir(parents=True, exist_ok=True)
            tmp_path = self._path.with_suffix(".tmp")
            with tmp_path.open("w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2)
            # Atomic rename / replace
            os.replace(str(tmp_path), str(self._path))
        except OSError:
            # Fallback direct write if replace fails
            try:
                with self._path.open("w", encoding="utf-8") as f:
                    json.dump(self._data, f, indent=2)
            except OSError:
                pass
