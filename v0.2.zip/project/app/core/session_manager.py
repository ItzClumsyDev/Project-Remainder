"""
Session manager — saves, loads, and queries work sessions from JSON.
Uses atomic file writing and thread safety to prevent save file corruption.

Session record schema:
{
    "id":                  str  (UUID),
    "date":                str  (YYYY-MM-DD),
    "mode":                str  ("timer" | "stopwatch"),
    "start_time":          str  (HH:MM:SS),
    "end_time":            str  (HH:MM:SS),
    "duration_seconds":    int,
    "target_duration":     int | null,
    "productivity_rating": int  (1–5),
    "notes":               str,
    "tasks_completed":     list[str]  (task IDs)
}
"""
from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

_DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"


class SessionManager:
    """Saves and loads work sessions from a local JSON file safely."""

    def __init__(self) -> None:
        _DATA_DIR.mkdir(parents=True, exist_ok=True)
        self._path = _DATA_DIR / "sessions.json"
        self._lock = threading.Lock()
        self._sessions: list[dict[str, Any]] = self._load()
        # Guarantee sessions.json file exists on disk
        if not self._path.exists():
            self._write()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def save_session(
        self,
        *,
        mode: str,
        start_time: str | None = None,
        end_time: str | None = None,
        duration_seconds: float,
        target_duration: int | None = None,
        productivity_rating: int = 3,
        notes: str = "",
        tasks_completed: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create and safely persist a completed session record."""
        now = datetime.now()
        cur_time = now.strftime("%H:%M:%S")
        
        session: dict[str, Any] = {
            "id": str(uuid.uuid4()),
            "date": now.strftime("%Y-%m-%d"),
            "mode": mode,
            "start_time": start_time or cur_time,
            "end_time": end_time or cur_time,
            "duration_seconds": max(0, int(duration_seconds)),
            "target_duration": target_duration,
            "productivity_rating": max(1, min(5, int(productivity_rating))),
            "notes": str(notes).strip(),
            "tasks_completed": tasks_completed or [],
        }

        with self._lock:
            # Re-sync before adding to avoid losing any externally modified records
            self._sessions.append(session)
            self._write()

        return session

    def get_all(self) -> list[dict[str, Any]]:
        """Return a copy of all saved sessions (oldest first)."""
        with self._lock:
            return list(self._sessions)

    def reload(self) -> None:
        """Re-read sessions from disk."""
        with self._lock:
            self._sessions = self._load()

    def delete_save_data(self) -> None:
        """
        Delete all saved session records safely.
        Clears the in-memory session list and removes sessions.json from disk.
        Handles missing files, already empty files, corrupted files, and OS errors safely.
        """
        with self._lock:
            self._sessions = []
            if self._path.exists():
                try:
                    self._path.unlink()
                except OSError as err:
                    # Fallback: try overwriting with empty sessions if delete is blocked
                    try:
                        with self._path.open("w", encoding="utf-8") as f:
                            json.dump({"sessions": []}, f, indent=2)
                    except Exception:
                        raise OSError(f"Could not delete or clear {self._path.name}: {err}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> list[dict[str, Any]]:
        try:
            if self._path.exists():
                with self._path.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        sessions = data.get("sessions", [])
                        if isinstance(sessions, list):
                            return sessions
        except (json.JSONDecodeError, OSError, ValueError):
            pass
        return []

    def _write(self) -> None:
        try:
            _DATA_DIR.mkdir(parents=True, exist_ok=True)
            tmp_path = self._path.with_suffix(".tmp")
            with tmp_path.open("w", encoding="utf-8") as f:
                json.dump({"sessions": self._sessions}, f, indent=2)
            os.replace(str(tmp_path), str(self._path))
        except OSError:
            try:
                with self._path.open("w", encoding="utf-8") as f:
                    json.dump({"sessions": self._sessions}, f, indent=2)
            except OSError:
                pass
