"""
Lightweight, zero-waste reminder scheduler.

Features:
  • Uses OS-level thread wait (threading.Event.wait) — 0% CPU consumption while waiting.
  • Dynamically wakes up immediately when reminders are added, edited, or removed.
  • Accurately fires notifications when the scheduled date/time arrives.
  • Ensures each notification triggers only once and marks it persisted.
  • Operates completely independent of the Timer or Stopwatch engines.
"""
from __future__ import annotations

import threading
import time
from datetime import datetime
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from .reminder_manager import ReminderManager


class ReminderScheduler:
    """Schedules and triggers reminders efficiently without polling or wasting CPU."""

    def __init__(
        self,
        reminder_mgr: "ReminderManager",
        on_trigger: Callable[[dict], None],
    ) -> None:
        self._mgr = reminder_mgr
        self._on_trigger = on_trigger
        self._wake_event = threading.Event()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

        # Listen for reminder changes to wake up immediately
        self._mgr.add_change_listener(self._wake_event.set)

    def start(self) -> None:
        """Start the background scheduler thread."""
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="PR-ReminderScheduler", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop the scheduler thread."""
        self._stop_event.set()
        self._wake_event.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

    def _run(self) -> None:
        while not self._stop_event.is_set():
            self._wake_event.clear()

            now = datetime.now()
            pending = self._mgr.get_pending_reminders()

            due_items = []
            upcoming_items = []

            for r in pending:
                date_str = r.get("date", "")
                time_str = r.get("time", "")
                try:
                    if len(time_str.split(":")) >= 3:
                        target_dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M:%S")
                    else:
                        target_dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
                    if target_dt <= now:
                        due_items.append((target_dt, r))
                    else:
                        upcoming_items.append((target_dt, r))
                except (ValueError, TypeError):
                    continue

            # Process due items first
            if due_items:
                for _, r in due_items:
                    # Mark as notified so it never triggers again
                    self._mgr.mark_notified(r["id"])
                    try:
                        self._on_trigger(r)
                    except Exception:
                        pass

            if self._stop_event.is_set():
                break

            # Calculate sleep duration to next upcoming item
            if upcoming_items:
                upcoming_items.sort(key=lambda x: x[0])
                earliest_dt, _ = upcoming_items[0]
                diff = (earliest_dt - datetime.now()).total_seconds()
                # Wait until exact second (capped at 300s for clock synchronization)
                sleep_seconds = max(0.5, min(diff, 300.0))
            else:
                # No upcoming reminders, sleep until woken up by change or hourly check
                sleep_seconds = 3600.0

            # Kernel sleep via Event.wait() — 0% CPU consumption
            self._wake_event.wait(timeout=sleep_seconds)
