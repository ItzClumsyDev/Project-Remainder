"""
Statistics engine — pure functions for aggregating session data.
No side effects; all functions are stateless and testable.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any


# ---------------------------------------------------------------------------
# Session filtering
# ---------------------------------------------------------------------------

def _parse_date(session: dict[str, Any]) -> date | None:
    try:
        return datetime.strptime(session["date"], "%Y-%m-%d").date()
    except (KeyError, ValueError, TypeError):
        return None


def filter_sessions(
    sessions: list[dict[str, Any]], period: str
) -> list[dict[str, Any]]:
    """
    Filter sessions strictly by the selected time range:
      • '1day' / 'today': only today's sessions (last 24 hours / current day)
      • '7days' / 'week': last 7 days (today - 6 days through today)
      • '1month' / 'month': last 30 days (today - 29 days through today)
      • '1year' / 'year': last 365 days (today - 364 days through today)
      • 'all': all sessions
    """
    today = date.today()
    p = period.lower().strip()

    if p in ("today", "day", "1day", "last 1 day"):
        start, end = today, today
    elif p in ("week", "7days", "7d", "last 7 days"):
        start, end = today - timedelta(days=6), today
    elif p in ("month", "1month", "30days", "last 1 month"):
        start, end = today - timedelta(days=29), today
    elif p in ("year", "1year", "365days", "last 1 year"):
        start, end = today - timedelta(days=364), today
    else:
        return list(sessions)

    return [s for s in sessions if (d := _parse_date(s)) and start <= d <= end]


# ---------------------------------------------------------------------------
# Aggregate statistics
# ---------------------------------------------------------------------------

def compute_stats(
    sessions: list[dict[str, Any]], period: str = "7days"
) -> dict[str, Any]:
    """Return aggregate statistics for a list of sessions appropriate to the period scale."""
    if not sessions:
        return {
            "total_sessions": 0,
            "total_seconds": 0,
            "avg_duration_seconds": 0.0,
            "avg_rating": 0.0,
            "most_productive_day": None,
            "most_productive_month": None,
            "avg_seconds_per_day": 0.0,
            "avg_seconds_per_month": 0.0,
            "daily_breakdown": {},
            "total_tasks_completed": 0,
        }

    total_seconds = sum(s.get("duration_seconds", 0) for s in sessions)
    ratings = [r for s in sessions if (r := s.get("productivity_rating")) and r > 0]
    avg_rating = round(sum(ratings) / len(ratings), 1) if ratings else 0.0
    avg_duration = total_seconds / len(sessions)

    # Per-day and per-month aggregates
    daily: dict[str, dict[str, float]] = {}
    monthly: dict[str, float] = {}

    for s in sessions:
        d = s.get("date", "unknown")
        dur = float(s.get("duration_seconds", 0))
        if d not in daily:
            daily[d] = {"sessions": 0, "seconds": 0.0, "total_rating": 0.0}
        daily[d]["sessions"] += 1
        daily[d]["seconds"] += dur
        daily[d]["total_rating"] += s.get("productivity_rating", 0)

        mo = d[:7]  # YYYY-MM
        monthly[mo] = monthly.get(mo, 0.0) + dur

    most_productive_day = (
        max(daily, key=lambda k: daily[k]["seconds"]) if daily else None
    )

    most_productive_month_key = (
        max(monthly, key=lambda k: monthly[k]) if monthly else None
    )
    most_productive_month = (
        readable_month(most_productive_month_key) if most_productive_month_key else None
    )

    total_tasks = sum(len(s.get("tasks_completed", [])) for s in sessions)

    avg_per_day = total_seconds / 30.0
    avg_per_month = total_seconds / 12.0

    return {
        "total_sessions": len(sessions),
        "total_seconds": total_seconds,
        "avg_duration_seconds": avg_duration,
        "avg_rating": avg_rating,
        "most_productive_day": most_productive_day,
        "most_productive_month": most_productive_month,
        "avg_seconds_per_day": avg_per_day,
        "avg_seconds_per_month": avg_per_month,
        "daily_breakdown": daily,
        "total_tasks_completed": total_tasks,
    }


# ---------------------------------------------------------------------------
# Chart data helpers
# ---------------------------------------------------------------------------

def get_period_chart_data(
    period: str, sessions: list[dict[str, Any]]
) -> dict[str, Any]:
    """
    Generate chart data strictly for the specified period:
      • '1day'   -> Session-by-session activity and ratings for today
      • '7days'  -> Daily minutes and productivity trend for the last 7 days
      • '1month' -> Weekly minutes and productivity trend for the last 4 weeks (30 days)
      • '1year'  -> Monthly minutes and productivity trend for the last 12 months
    """
    today = date.today()
    p = period.lower().strip()

    if p in ("today", "day", "1day", "last 1 day"):
        day_sessions = sorted(sessions, key=lambda s: s.get("start_time", ""))
        bar_data: list[tuple[str, float]] = []
        line_data: list[tuple[str, float]] = []

        if len(day_sessions) <= 8:
            for i, s in enumerate(day_sessions):
                lbl = s.get("start_time", "")[:5] or f"S{i+1}"
                mins = round(s.get("duration_seconds", 0) / 60.0, 1)
                rating = float(s.get("productivity_rating", 0))
                bar_data.append((lbl, mins))
                line_data.append((lbl, rating))
        else:
            slots = [
                ("00:00", 0, 4),
                ("04:00", 4, 8),
                ("08:00", 8, 12),
                ("12:00", 12, 16),
                ("16:00", 16, 20),
                ("20:00", 20, 24),
            ]
            for lbl, h_start, h_end in slots:
                slot_s = [
                    s for s in day_sessions
                    if h_start <= int((s.get("start_time", "00:00") or "00:00")[:2] or 0) < h_end
                ]
                mins = round(sum(s.get("duration_seconds", 0) for s in slot_s) / 60.0, 1)
                ratings = [r for s in slot_s if (r := s.get("productivity_rating")) and r > 0]
                avg_r = round(sum(ratings) / len(ratings), 1) if ratings else 0.0
                bar_data.append((lbl, mins))
                line_data.append((lbl, avg_r))

        return {
            "bar_title": "Session Activity  (minutes worked)",
            "bar_data": bar_data,
            "line_title": "Session Productivity  (rating 1–5)",
            "line_data": line_data,
            "max_y": 5.0,
        }

    elif p in ("month", "1month", "30days", "last 1 month"):
        bar_data = []
        line_data = []
        for w in range(3, -1, -1):
            w_end = today - timedelta(days=w * 7)
            w_start = today - timedelta(days=w * 7 + 6)
            week_s = [
                s for s in sessions
                if (d := _parse_date(s)) and w_start <= d <= w_end
            ]
            mins = round(sum(s.get("duration_seconds", 0) for s in week_s) / 60.0, 1)
            ratings = [r for s in week_s if (r := s.get("productivity_rating")) and r > 0]
            avg_r = round(sum(ratings) / len(ratings), 1) if ratings else 0.0

            if w_start.month != w_end.month:
                lbl = f"{w_start.strftime('%d %b')}–{w_end.strftime('%d %b')}"
            else:
                lbl = f"{w_start.strftime('%d')}–{w_end.strftime('%d %b')}"

            bar_data.append((lbl, mins))
            line_data.append((lbl, avg_r))

        return {
            "bar_title": "Weekly Minutes Worked  (last 4 weeks)",
            "bar_data": bar_data,
            "line_title": "Weekly Productivity Trend  (last 4 weeks)",
            "line_data": line_data,
            "max_y": 5.0,
        }

    elif p in ("year", "1year", "365days", "last 1 year"):
        bar_data = []
        line_data = []
        cur_y, cur_m = today.year, today.month
        for m in range(11, -1, -1):
            total_m = cur_y * 12 + (cur_m - 1) - m
            y = total_m // 12
            mo = (total_m % 12) + 1
            mo_prefix = f"{y:04d}-{mo:02d}"
            mo_s = [s for s in sessions if s.get("date", "").startswith(mo_prefix)]
            mins = round(sum(s.get("duration_seconds", 0) for s in mo_s) / 60.0, 1)
            ratings = [r for s in mo_s if (r := s.get("productivity_rating")) and r > 0]
            avg_r = round(sum(ratings) / len(ratings), 1) if ratings else 0.0

            lbl = date(y, mo, 1).strftime("%b")
            bar_data.append((lbl, mins))
            line_data.append((lbl, avg_r))

        return {
            "bar_title": "Monthly Minutes Worked  (last 12 months)",
            "bar_data": bar_data,
            "line_title": "Monthly Productivity Trend  (last 12 months)",
            "line_data": line_data,
            "max_y": 5.0,
        }

    else:  # '7days' / 'week'
        bar_data = []
        line_data = []
        for i in range(6, -1, -1):
            d_obj = today - timedelta(days=i)
            d_str = d_obj.strftime("%Y-%m-%d")
            day_s = [s for s in sessions if s.get("date") == d_str]
            mins = round(sum(s.get("duration_seconds", 0) for s in day_s) / 60.0, 1)
            ratings = [r for s in day_s if (r := s.get("productivity_rating")) and r > 0]
            avg_r = round(sum(ratings) / len(ratings), 1) if ratings else 0.0

            lbl = d_obj.strftime("%a")
            bar_data.append((lbl, mins))
            line_data.append((lbl, avg_r))

        return {
            "bar_title": "Daily Minutes Worked  (last 7 days)",
            "bar_data": bar_data,
            "line_title": "Productivity Trend  (last 7 days)",
            "line_data": line_data,
            "max_y": 5.0,
        }


def get_daily_work_minutes(
    sessions: list[dict[str, Any]], days: int = 7
) -> list[tuple[str, float]]:
    """(date_str, total_minutes) for the last `days` days."""
    today = date.today()
    result: list[tuple[str, float]] = []
    for i in range(days - 1, -1, -1):
        d = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        mins = sum(
            s.get("duration_seconds", 0) for s in sessions if s.get("date") == d
        ) / 60.0
        result.append((d, mins))
    return result


def get_productivity_trend(
    sessions: list[dict[str, Any]], days: int = 7
) -> list[tuple[str, float]]:
    """(date_str, avg_rating) for the last `days` days. Zero if no sessions."""
    today = date.today()
    result: list[tuple[str, float]] = []
    for i in range(days - 1, -1, -1):
        d = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        day_s = [s for s in sessions if s.get("date") == d]
        avg = (
            sum(s.get("productivity_rating", 0) for s in day_s) / len(day_s)
            if day_s
            else 0.0
        )
        result.append((d, avg))
    return result


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def fmt_duration(seconds: float) -> str:
    """Format seconds as '2h 15m', '45m', or '30s'."""
    s = int(seconds)
    if s >= 3600:
        h, rem = divmod(s, 3600)
        m = rem // 60
        return f"{h}h {m}m" if m else f"{h}h"
    if s >= 60:
        return f"{s // 60}m"
    return f"{s}s"


def fmt_clock(seconds: float) -> str:
    """Format as MM:SS or HH:MM:SS."""
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, sc = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{sc:02d}" if h else f"{m:02d}:{sc:02d}"


def day_name(date_str: str) -> str:
    """Return short weekday name (Mon, Tue…) for a YYYY-MM-DD string."""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").strftime("%a")
    except ValueError:
        return date_str


def readable_date(date_str: str) -> str:
    """Return human-readable date like 'Mon 31 Aug'."""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").strftime("%a %d %b")
    except ValueError:
        return date_str


def readable_month(month_str: str) -> str:
    """Return 'August 2026' from '2026-08'."""
    try:
        return datetime.strptime(f"{month_str}-01", "%Y-%m-%d").strftime("%B %Y")
    except ValueError:
        return month_str

