"""
Reminder manager — local persistence and CRUD for calendar events and reminders.

Supports:
  • Local JSON storage in data/reminders.json
  • Atomic write operations using temporary files
  • Robust error handling for corrupted/missing data
  • Thread-safe change notification callbacks
"""
from __future__ import annotations

import json
import os
import re
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

# Resolve path: app/core/ → app/ → ProjectRemainder/ → data/
_DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"


def normalize_time(raw: str) -> tuple[str, str]:
    """
    Parse a user-entered time string into (24h_str 'HH:MM', display_str 'H:MM AM/PM').
    Handles various formats: '19:00', '7:00 PM', '7:00pm', '7pm', '07:30', etc.
    Falls back to current time if unparseable.
    """
    cleaned = raw.strip()
    if not cleaned:
        now = datetime.now()
        return now.strftime("%H:%M"), now.strftime("%I:%M %p").lstrip("0")

    # Try common formats
    formats = [
        "%I:%M %p",
        "%I:%M%p",
        "%I %p",
        "%I%p",
        "%H:%M",
        "%H:%M:%S",
    ]
    for fmt in formats:
        try:
            dt = datetime.strptime(cleaned.upper(), fmt)
            if fmt == "%H:%M:%S" or dt.second > 0:
                hh_mm = dt.strftime("%H:%M:%S")
                display = dt.strftime("%I:%M:%S %p").lstrip("0")
            else:
                hh_mm = dt.strftime("%H:%M")
                display = dt.strftime("%I:%M %p").lstrip("0")
            if not display.startswith(("10", "11", "12")):
                # Ensure single digit hour doesn't have leading space
                display = display.strip()
            return hh_mm, display
        except ValueError:
            continue

    # Regex heuristic fallback (e.g., '7' or '7:30')
    m = re.match(r"^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$", cleaned, re.IGNORECASE)
    if m:
        h = int(m.group(1))
        min_val = int(m.group(2)) if m.group(2) else 0
        ampm = m.group(3).upper() if m.group(3) else None
        if ampm == "PM" and h < 12:
            h += 12
        elif ampm == "AM" and h == 12:
            h = 0
        h = max(0, min(23, h))
        min_val = max(0, min(59, min_val))
        dt = datetime(2000, 1, 1, h, min_val)
        return dt.strftime("%H:%M"), dt.strftime("%I:%M %p").lstrip("0").strip()

    now = datetime.now()
    return now.strftime("%H:%M"), now.strftime("%I:%M %p").lstrip("0")


class ReminderManager:
    """Manages calendar events and scheduled reminders."""

    def __init__(self) -> None:
        _DATA_DIR.mkdir(parents=True, exist_ok=True)
        self._path = _DATA_DIR / "reminders.json"
        self._lock = threading.Lock()
        self._listeners: list[Callable[[], None]] = []
        self._reminders: list[dict[str, Any]] = self._load()
        if not self._path.exists():
            self._write()

    # ------------------------------------------------------------------
    # Listeners
    # ------------------------------------------------------------------

    def add_change_listener(self, cb: Callable[[], None]) -> None:
        """Register a callback invoked whenever reminders are modified."""
        with self._lock:
            if cb not in self._listeners:
                self._listeners.append(cb)

    def _notify_listeners(self) -> None:
        listeners = list(self._listeners)
        for cb in listeners:
            try:
                cb()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Public CRUD API
    # ------------------------------------------------------------------

    def get_all(self) -> list[dict[str, Any]]:
        """Return all reminders sorted by date then time."""
        with self._lock:
            return sorted(
                self._reminders,
                key=lambda r: (r.get("date", ""), r.get("time", ""))
            )

    def get_for_date(self, date_str: str) -> list[dict[str, Any]]:
        """Return reminders for a specific date (YYYY-MM-DD), sorted by time."""
        with self._lock:
            matched = [r for r in self._reminders if r.get("date") == date_str]
            return sorted(matched, key=lambda r: r.get("time", ""))

    def get_dates_with_reminders(self) -> set[str]:
        """Return a set of YYYY-MM-DD date strings that have at least one reminder."""
        with self._lock:
            return {r.get("date") for r in self._reminders if r.get("date")}

    def get_pending_reminders(self) -> list[dict[str, Any]]:
        """Return all reminders that have notifications enabled and not yet triggered."""
        with self._lock:
            return [
                dict(r) for r in self._reminders
                if r.get("notify", True) and not r.get("notified", False)
            ]

    def add_reminder(
        self,
        title: str,
        date: str,
        time_str: str,
        notes: str = "",
        notify: bool = True,
    ) -> dict[str, Any]:
        time_24, time_display = normalize_time(time_str)
        item: dict[str, Any] = {
            "id": str(uuid.uuid4()),
            "title": title.strip(),
            "date": date.strip(),
            "time": time_24,
            "time_display": time_display,
            "notes": notes.strip(),
            "notify": bool(notify),
            "notified": False,
            "created_at": datetime.now().isoformat(),
        }
        with self._lock:
            self._reminders.append(item)
            self._write()

        self._notify_listeners()
        return item

    def update_reminder(
        self,
        reminder_id: str,
        title: str,
        date: str,
        time_str: str,
        notes: str = "",
        notify: bool = True,
        reset_notified: bool = True,
    ) -> bool:
        time_24, time_display = normalize_time(time_str)
        found = False
        with self._lock:
            for r in self._reminders:
                if r.get("id") == reminder_id:
                    r["title"] = title.strip()
                    r["date"] = date.strip()
                    r["time"] = time_24
                    r["time_display"] = time_display
                    r["notes"] = notes.strip()
                    r["notify"] = bool(notify)
                    if reset_notified:
                        r["notified"] = False
                    found = True
                    break
            if found:
                self._write()

        if found:
            self._notify_listeners()
        return found

    def delete_reminder(self, reminder_id: str) -> bool:
        found = False
        with self._lock:
            before = len(self._reminders)
            self._reminders = [r for r in self._reminders if r.get("id") != reminder_id]
            found = len(self._reminders) < before
            if found:
                self._write()

        if found:
            self._notify_listeners()
        return found

    def mark_notified(self, reminder_id: str) -> bool:
        """Mark a reminder as notified so it does not fire again."""
        found = False
        with self._lock:
            for r in self._reminders:
                if r.get("id") == reminder_id:
                    r["notified"] = True
                    found = True
                    break
            if found:
                self._write()
        return found

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _load(self) -> list[dict[str, Any]]:
        if not self._path.exists():
            return []
        try:
            with self._path.open("r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    raw_list = data.get("reminders", [])
                    if isinstance(raw_list, list):
                        valid = []
                        for item in raw_list:
                            if isinstance(item, dict) and "id" in item and "title" in item:
                                # Ensure default fields exist
                                item.setdefault("notes", "")
                                item.setdefault("notify", True)
                                item.setdefault("notified", False)
                                if "time" in item and "time_display" not in item:
                                    _, item["time_display"] = normalize_time(item["time"])
                                valid.append(item)
                        return valid
        except (json.JSONDecodeError, OSError, ValueError):
            pass
        return []

    def _write(self) -> None:
        try:
            _DATA_DIR.mkdir(parents=True, exist_ok=True)
            tmp_path = self._path.with_suffix(".tmp")
            with tmp_path.open("w", encoding="utf-8") as f:
                json.dump({"reminders": self._reminders}, f, indent=2)
            os.replace(str(tmp_path), str(self._path))
        except OSError:
            try:
                with self._path.open("w", encoding="utf-8") as f:
                    json.dump({"reminders": self._reminders}, f, indent=2)
            except OSError:
                pass
