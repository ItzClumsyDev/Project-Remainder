"""
Audio player module for Project Remainder.

Supports playing custom MP3, WAV, and audio files natively on Windows
using the built-in Windows Multimedia API (winmm.dll / MCI) with zero external dependencies.
Falls back gracefully to winsound system beeps.
"""
from __future__ import annotations

import ctypes
import os
import threading
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .settings_manager import SettingsManager

_ALIAS = "pr_alarm_sound"
_IS_WINDOWS = os.name == "nt"
_lock = threading.Lock()
_current_file: str | None = None

if _IS_WINDOWS:
    try:
        _winmm = ctypes.windll.winmm
    except Exception:
        _winmm = None
else:
    _winmm = None


def get_sound_state() -> str:
    """
    Get the current playback state of the audio player.
    Returns: 'playing', 'paused', or 'stopped'.
    """
    if _winmm is None:
        return "stopped"
    try:
        buf = ctypes.create_unicode_buffer(128)
        res = _winmm.mciSendStringW(f'status {_ALIAS} mode', buf, 128, None)
        if res == 0:
            mode = buf.value.lower().strip()
            if mode in ("playing", "paused", "stopped"):
                return mode
    except Exception:
        pass
    return "stopped"


def play_sound_file(file_path: str | None = None) -> None:
    """
    Play a sound file (MP3, WAV, etc.) in a background daemon thread.
    If file_path is None or playback fails, plays the system notification sound.
    Always restarts playback from the beginning (used for alarms/notifications).
    """
    def _worker() -> None:
        global _current_file
        with _lock:
            if file_path and os.path.isfile(file_path) and _winmm is not None:
                try:
                    path_obj = Path(file_path).resolve()
                    clean_path = str(path_obj)

                    # Stop and close any previous instance
                    _winmm.mciSendStringW(f'close {_ALIAS}', None, 0, None)

                    # Open with mpegvideo type for MP3/audio files
                    ext = path_obj.suffix.lower()
                    if ext in (".mp3", ".m4a", ".aac", ".wma"):
                        cmd = f'open "{clean_path}" type mpegvideo alias {_ALIAS}'
                    else:
                        cmd = f'open "{clean_path}" alias {_ALIAS}'

                    res = _winmm.mciSendStringW(cmd, None, 0, None)
                    if res != 0:
                        # Retry generic open
                        res = _winmm.mciSendStringW(f'open "{clean_path}" alias {_ALIAS}', None, 0, None)

                    if res == 0:
                        _winmm.mciSendStringW(f'play {_ALIAS} from 0', None, 0, None)
                        _current_file = clean_path
                        return
                except Exception:
                    pass

            # Fallback: Windows system beep
            _current_file = None
            _fallback_beep()

    threading.Thread(target=_worker, daemon=True).start()


def play_test_sound(file_path: str | None = None) -> bool:
    """
    Start playing the selected sound file for testing.
    - If the test sound is already playing, does NOT create another playback instance or restart.
    - If the sound is currently paused on the same file, resumes playback.
    - Otherwise, opens and starts playing the sound from the beginning.
    Returns True if playback started or resumed, False if already playing or failed.
    """
    global _current_file
    with _lock:
        state = get_sound_state()

        # If already playing, do not create another loop or restart
        if state == "playing":
            return False

        if file_path and os.path.isfile(file_path) and _winmm is not None:
            try:
                path_obj = Path(file_path).resolve()
                clean_path = str(path_obj)

                # If paused on the same file, resume
                if state == "paused" and _current_file == clean_path:
                    res = _winmm.mciSendStringW(f'resume {_ALIAS}', None, 0, None)
                    if res != 0:
                        res = _winmm.mciSendStringW(f'play {_ALIAS}', None, 0, None)
                    return res == 0

                # Otherwise open and play from 0
                _winmm.mciSendStringW(f'close {_ALIAS}', None, 0, None)

                ext = path_obj.suffix.lower()
                if ext in (".mp3", ".m4a", ".aac", ".wma"):
                    cmd = f'open "{clean_path}" type mpegvideo alias {_ALIAS}'
                else:
                    cmd = f'open "{clean_path}" alias {_ALIAS}'

                res = _winmm.mciSendStringW(cmd, None, 0, None)
                if res != 0:
                    res = _winmm.mciSendStringW(f'open "{clean_path}" alias {_ALIAS}', None, 0, None)

                if res == 0:
                    res = _winmm.mciSendStringW(f'play {_ALIAS} from 0', None, 0, None)
                    if res == 0:
                        _current_file = clean_path
                        return True
            except Exception:
                pass

        # Fallback beep if no file or error
        _current_file = None
        _fallback_beep()
        return True


def pause_sound() -> bool:
    """Pause currently playing audio. Returns True if paused."""
    with _lock:
        if _winmm is not None and get_sound_state() == "playing":
            res = _winmm.mciSendStringW(f'pause {_ALIAS}', None, 0, None)
            return res == 0
        return False


def resume_sound() -> bool:
    """Resume paused audio. Returns True if resumed."""
    with _lock:
        if _winmm is not None and get_sound_state() == "paused":
            res = _winmm.mciSendStringW(f'resume {_ALIAS}', None, 0, None)
            if res != 0:
                res = _winmm.mciSendStringW(f'play {_ALIAS}', None, 0, None)
            return res == 0
        return False


def toggle_pause_sound() -> str:
    """
    Toggle pause / resume on active sound playback.
    Returns current state: 'playing', 'paused', or 'stopped'.
    """
    state = get_sound_state()
    if state == "playing":
        if pause_sound():
            return "paused"
    elif state == "paused":
        if resume_sound():
            return "playing"
    return get_sound_state()


_alarm_stop_event = threading.Event()
_alarm_thread: threading.Thread | None = None


def play_alarm(settings_mgr: "SettingsManager") -> None:
    """Check settings and play the configured alarm sound in a continuous loop until stopped."""
    if not settings_mgr.get("sound_enabled", True):
        return

    custom_sound = settings_mgr.get("custom_sound_path", "")
    _start_alarm_loop(custom_sound if custom_sound else None)


def _start_alarm_loop(file_path: str | None = None) -> None:
    global _alarm_thread, _current_file
    stop_sound()
    with _lock:
        _alarm_stop_event.clear()

        def _worker() -> None:
            global _current_file
            if file_path and os.path.isfile(file_path) and _winmm is not None:
                try:
                    path_obj = Path(file_path).resolve()
                    clean_path = str(path_obj)
                    ext = path_obj.suffix.lower()
                    if ext in (".mp3", ".m4a", ".aac", ".wma"):
                        cmd = f'open "{clean_path}" type mpegvideo alias {_ALIAS}'
                    else:
                        cmd = f'open "{clean_path}" alias {_ALIAS}'

                    _winmm.mciSendStringW(f'close {_ALIAS}', None, 0, None)
                    res = _winmm.mciSendStringW(cmd, None, 0, None)
                    if res != 0:
                        res = _winmm.mciSendStringW(f'open "{clean_path}" alias {_ALIAS}', None, 0, None)

                    if res == 0:
                        _current_file = clean_path
                        _winmm.mciSendStringW(f'play {_ALIAS} from 0', None, 0, None)
                        buf = ctypes.create_unicode_buffer(128)
                        while not _alarm_stop_event.is_set():
                            _alarm_stop_event.wait(0.2)
                            if _alarm_stop_event.is_set():
                                break
                            res = _winmm.mciSendStringW(f'status {_ALIAS} mode', buf, 128, None)
                            if res == 0 and buf.value.lower().strip() == "stopped":
                                _winmm.mciSendStringW(f'play {_ALIAS} from 0', None, 0, None)
                        return
                except Exception:
                    pass

            # Fallback beep loop
            while not _alarm_stop_event.is_set():
                _fallback_beep()
                _alarm_stop_event.wait(1.2)

        _alarm_thread = threading.Thread(target=_worker, daemon=True)
        _alarm_thread.start()


def stop_sound() -> None:
    """Stop and close any active sound playback or alarm loop."""
    global _current_file
    _alarm_stop_event.set()
    with _lock:
        if _winmm is not None:
            try:
                _winmm.mciSendStringW(f'stop {_ALIAS}', None, 0, None)
                _winmm.mciSendStringW(f'close {_ALIAS}', None, 0, None)
            except Exception:
                pass
        _current_file = None


def _fallback_beep() -> None:
    try:
        import winsound
        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
    except Exception:
        # Cross-platform bell fallback
        print("\a", end="", flush=True)


