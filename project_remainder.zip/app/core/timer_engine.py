"""
Timer engine — thread-safe countdown timer and stopwatch.

Events pushed to the shared queue (consumed by the UI thread via after()):
    {'type': 'tick',   'elapsed': float, 'total': float, 'mode': str, 'paused': bool}
    {'type': 'finish', 'elapsed': float, 'total': float, 'mode': str}

All public methods are thread-safe.
UI updates MUST happen on the main thread — use after() to dequeue events.
"""
from __future__ import annotations

import queue
import threading
import time
from typing import Any, Callable


class TimerEngine:
    """Runs a countdown timer or stopwatch in a background daemon thread."""

    TICK_INTERVAL: float = 0.1        # seconds between ticks
    CHECKPOINT_INTERVAL: float = 5.0  # seconds between state checkpoints

    def __init__(self, event_queue: "queue.Queue[dict[str, Any]]") -> None:
        self.event_queue = event_queue
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()

        # Mutable state protected by _lock
        self.mode: str | None = None           # 'timer' | 'stopwatch'
        self.total_seconds: float = 0.0
        self.elapsed_seconds: float = 0.0
        self.is_running: bool = False
        self.is_paused: bool = False
        self.session_start_time: str | None = None  # ISO-format wall-clock start

        self._on_checkpoint: Callable[[dict[str, Any]], None] | None = None

    # ------------------------------------------------------------------
    # Public control API
    # ------------------------------------------------------------------

    def start_timer(
        self,
        seconds: int,
        on_checkpoint: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        """Start a countdown timer for `seconds` seconds."""
        self._reset()
        with self._lock:
            self.mode = "timer"
            self.total_seconds = float(max(1, seconds))
            self.elapsed_seconds = 0.0
            self.is_running = True
            self.is_paused = False
            self.session_start_time = time.strftime("%H:%M:%S")
            self._on_checkpoint = on_checkpoint
        self._stop_event.clear()
        self._launch()

    def start_stopwatch(
        self,
        on_checkpoint: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        """Start a stopwatch (counts up indefinitely until stopped)."""
        self._reset()
        with self._lock:
            self.mode = "stopwatch"
            self.total_seconds = 0.0
            self.elapsed_seconds = 0.0
            self.is_running = True
            self.is_paused = False
            self.session_start_time = time.strftime("%H:%M:%S")
            self._on_checkpoint = on_checkpoint
        self._stop_event.clear()
        self._launch()

    def pause(self) -> None:
        with self._lock:
            if self.is_running:
                self.is_paused = True

    def resume(self) -> None:
        with self._lock:
            if self.is_running:
                self.is_paused = False

    def toggle_pause(self) -> bool:
        """Toggle pause. Returns True if now paused."""
        with self._lock:
            if self.is_running:
                self.is_paused = not self.is_paused
                return self.is_paused
        return False

    def stop(self) -> None:
        """Stop and discard the current session."""
        self._stop_event.set()
        with self._lock:
            self.is_running = False
            self.is_paused = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=0.6)

    def get_state(self) -> dict[str, Any]:
        """Thread-safe snapshot of engine state."""
        with self._lock:
            return {
                "mode": self.mode,
                "total_seconds": self.total_seconds,
                "elapsed_seconds": self.elapsed_seconds,
                "is_running": self.is_running,
                "is_paused": self.is_paused,
                "session_start_time": self.session_start_time,
            }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _reset(self) -> None:
        """Stop any running thread before starting a new one."""
        if self._thread and self._thread.is_alive():
            self.stop()
        self._stop_event.clear()

    def _launch(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        last_wall = time.monotonic()
        last_checkpoint = time.monotonic()

        while not self._stop_event.is_set():
            # Sleep in small intervals so stop_event is checked frequently
            self._stop_event.wait(timeout=self.TICK_INTERVAL)
            if self._stop_event.is_set():
                break

            now = time.monotonic()
            dt = now - last_wall
            last_wall = now

            with self._lock:
                if not self.is_paused and self.is_running:
                    self.elapsed_seconds += dt
                elapsed = self.elapsed_seconds
                total = self.total_seconds
                mode = self.mode
                paused = self.is_paused

            # Enqueue tick (drop if queue is full — prevents backlog)
            try:
                self.event_queue.put_nowait({
                    "type": "tick",
                    "elapsed": elapsed,
                    "total": total,
                    "mode": mode,
                    "paused": paused,
                })
            except queue.Full:
                pass

            # Check timer completion
            if mode == "timer" and elapsed >= total:
                with self._lock:
                    self.is_running = False
                try:
                    self.event_queue.put({
                        "type": "finish",
                        "elapsed": elapsed,
                        "total": total,
                        "mode": mode,
                        "paused": False,
                    }, timeout=1.0)
                except queue.Full:
                    pass
                break

            # Periodic state checkpoint (for session recovery)
            if now - last_checkpoint >= self.CHECKPOINT_INTERVAL:
                last_checkpoint = now
                if self._on_checkpoint:
                    try:
                        self._on_checkpoint(self.get_state())
                    except Exception:
                        pass
