"""Project Remainder — core logic package."""
