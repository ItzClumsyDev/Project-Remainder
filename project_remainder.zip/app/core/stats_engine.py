"""
Statistics engine — pure functions for aggregating session data.
No side effects; all functions are stateless and testable.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any


# ---------------------------------------------------------------------------
# Session filtering
# ---------------------------------------------------------------------------

def _parse_date(session: dict[str, Any]) -> date | None:
    try:
        return datetime.strptime(session["date"], "%Y-%m-%d").date()
    except (KeyError, ValueError, TypeError):
        return None


def filter_sessions(
    sessions: list[dict[str, Any]], period: str
) -> list[dict[str, Any]]:
    """
    Filter sessions by period.
    period: 'today' | 'week' | 'month' | 'year' | 'all'
    """
    today = date.today()

    if period == "today":
        start, end = today, today
    elif period == "week":
        start = today - timedelta(days=today.weekday())  # Monday
        end = start + timedelta(days=6)
    elif period == "month":
        start = today.replace(day=1)
        end = today
    elif period == "year":
        start = today.replace(month=1, day=1)
        end = today
    else:  # 'all'
        return list(sessions)

    return [s for s in sessions if (d := _parse_date(s)) and start <= d <= end]


# ---------------------------------------------------------------------------
# Aggregate statistics
# ---------------------------------------------------------------------------

def compute_stats(sessions: list[dict[str, Any]]) -> dict[str, Any]:
    """Return aggregate statistics for a list of sessions."""
    if not sessions:
        return {
            "total_sessions": 0,
            "total_seconds": 0,
            "avg_duration_seconds": 0.0,
            "avg_rating": 0.0,
            "most_productive_day": None,
            "daily_breakdown": {},
            "total_tasks_completed": 0,
        }

    total_seconds = sum(s.get("duration_seconds", 0) for s in sessions)
    ratings = [r for s in sessions if (r := s.get("productivity_rating")) and r > 0]
    avg_rating = round(sum(ratings) / len(ratings), 1) if ratings else 0.0
    avg_duration = total_seconds / len(sessions)

    # Per-day aggregates
    daily: dict[str, dict[str, float]] = {}
    for s in sessions:
        d = s.get("date", "unknown")
        if d not in daily:
            daily[d] = {"sessions": 0, "seconds": 0.0, "total_rating": 0.0}
        daily[d]["sessions"] += 1
        daily[d]["seconds"] += s.get("duration_seconds", 0)
        daily[d]["total_rating"] += s.get("productivity_rating", 0)

    most_productive_day = (
        max(daily, key=lambda k: daily[k]["seconds"]) if daily else None
    )

    total_tasks = sum(len(s.get("tasks_completed", [])) for s in sessions)

    return {
        "total_sessions": len(sessions),
        "total_seconds": total_seconds,
        "avg_duration_seconds": avg_duration,
        "avg_rating": avg_rating,
        "most_productive_day": most_productive_day,
        "daily_breakdown": daily,
        "total_tasks_completed": total_tasks,
    }


# ---------------------------------------------------------------------------
# Chart data helpers
# ---------------------------------------------------------------------------

def get_daily_work_minutes(
    sessions: list[dict[str, Any]], days: int = 7
) -> list[tuple[str, float]]:
    """(date_str, total_minutes) for the last `days` days."""
    today = date.today()
    result: list[tuple[str, float]] = []
    for i in range(days - 1, -1, -1):
        d = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        mins = sum(
            s.get("duration_seconds", 0) for s in sessions if s.get("date") == d
        ) / 60.0
        result.append((d, mins))
    return result


def get_productivity_trend(
    sessions: list[dict[str, Any]], days: int = 7
) -> list[tuple[str, float]]:
    """(date_str, avg_rating) for the last `days` days. Zero if no sessions."""
    today = date.today()
    result: list[tuple[str, float]] = []
    for i in range(days - 1, -1, -1):
        d = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        day_s = [s for s in sessions if s.get("date") == d]
        avg = (
            sum(s.get("productivity_rating", 0) for s in day_s) / len(day_s)
            if day_s
            else 0.0
        )
        result.append((d, avg))
    return result


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def fmt_duration(seconds: float) -> str:
    """Format seconds as '2h 15m', '45m', or '30s'."""
    s = int(seconds)
    if s >= 3600:
        h, rem = divmod(s, 3600)
        m = rem // 60
        return f"{h}h {m}m" if m else f"{h}h"
    if s >= 60:
        return f"{s // 60}m"
    return f"{s}s"


def fmt_clock(seconds: float) -> str:
    """Format as MM:SS or HH:MM:SS."""
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, sc = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{sc:02d}" if h else f"{m:02d}:{sc:02d}"


def day_name(date_str: str) -> str:
    """Return short weekday name (Mon, Tue…) for a YYYY-MM-DD string."""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").strftime("%a")
    except ValueError:
        return date_str


def readable_date(date_str: str) -> str:
    """Return human-readable date like 'Mon 31 Aug'."""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").strftime("%a %d %b")
    except ValueError:
        return date_str
