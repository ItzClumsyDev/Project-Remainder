"""
Audio player module for Project Remainder.

Supports playing custom MP3, WAV, and audio files natively on Windows
using the built-in Windows Multimedia API (winmm.dll / MCI) with zero external dependencies.
Falls back gracefully to winsound system beeps.
"""
from __future__ import annotations

import ctypes
import os
import threading
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .settings_manager import SettingsManager

_ALIAS = "pr_alarm_sound"
_IS_WINDOWS = os.name == "nt"

if _IS_WINDOWS:
    try:
        _winmm = ctypes.windll.winmm
    except Exception:
        _winmm = None
else:
    _winmm = None


def play_sound_file(file_path: str | None = None) -> None:
    """
    Play a sound file (MP3, WAV, etc.) in a background daemon thread.
    If file_path is None or playback fails, plays the system notification sound.
    """
    def _worker() -> None:
        if file_path and os.path.isfile(file_path) and _winmm is not None:
            try:
                path_obj = Path(file_path).resolve()
                # Windows MCI uses short path if available or double-quoted full path
                clean_path = str(path_obj)
                
                # Stop and close any previous instance
                _winmm.mciSendStringW(f'close {_ALIAS}', None, 0, None)
                
                # Open with mpegvideo type for MP3/audio files
                ext = path_obj.suffix.lower()
                if ext in (".mp3", ".m4a", ".aac"):
                    cmd = f'open "{clean_path}" type mpegvideo alias {_ALIAS}'
                else:
                    cmd = f'open "{clean_path}" alias {_ALIAS}'
                
                res = _winmm.mciSendStringW(cmd, None, 0, None)
                if res != 0:
                    # Retry generic open
                    res = _winmm.mciSendStringW(f'open "{clean_path}" alias {_ALIAS}', None, 0, None)
                
                if res == 0:
                    _winmm.mciSendStringW(f'play {_ALIAS} from 0', None, 0, None)
                    return
            except Exception:
                pass

        # Fallback: Windows system beep
        _fallback_beep()

    threading.Thread(target=_worker, daemon=True).start()


def play_alarm(settings_mgr: "SettingsManager") -> None:
    """Check settings and play the configured alarm sound."""
    if not settings_mgr.get("sound_enabled", True):
        return

    custom_sound = settings_mgr.get("custom_sound_path", "")
    play_sound_file(custom_sound if custom_sound else None)


def stop_sound() -> None:
    """Stop and close any active sound playback."""
    if _winmm is not None:
        try:
            _winmm.mciSendStringW(f'stop {_ALIAS}', None, 0, None)
            _winmm.mciSendStringW(f'close {_ALIAS}', None, 0, None)
        except Exception:
            pass


def _fallback_beep() -> None:
    try:
        import winsound
        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
    except Exception:
        # Cross-platform bell fallback
        print("\a", end="", flush=True)
