"""
To-do list manager — simple task CRUD with local JSON persistence.
Uses atomic file writing to prevent data corruption.

Task record schema:
{
    "id":         str  (UUID),
    "text":       str,
    "completed":  bool,
    "created_at": str  (ISO datetime),
    "order":      int  (for display ordering)
}
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

_DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"


class TodoManager:
    """Persists and manages to-do tasks in a local JSON file safely."""

    def __init__(self) -> None:
        _DATA_DIR.mkdir(parents=True, exist_ok=True)
        self._path = _DATA_DIR / "todos.json"
        self._tasks: list[dict[str, Any]] = self._load()
        if not self._path.exists():
            self._write()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_all(self) -> list[dict[str, Any]]:
        """Return all tasks sorted by order index."""
        return sorted(self._tasks, key=lambda t: t.get("order", 0))

    def get_incomplete(self) -> list[dict[str, Any]]:
        """Return only incomplete tasks, sorted by order."""
        return [t for t in self.get_all() if not t.get("completed", False)]

    def add_task(self, text: str) -> dict[str, Any]:
        max_order = max((t.get("order", 0) for t in self._tasks), default=0)
        task: dict[str, Any] = {
            "id": str(uuid.uuid4()),
            "text": text.strip(),
            "completed": False,
            "created_at": datetime.now().isoformat(),
            "order": max_order + 1,
        }
        self._tasks.append(task)
        self._write()
        return task

    def update_text(self, task_id: str, new_text: str) -> bool:
        for task in self._tasks:
            if task["id"] == task_id:
                task["text"] = new_text.strip()
                self._write()
                return True
        return False

    def toggle_complete(self, task_id: str) -> bool:
        """Flip the completed state of a task. Returns True if found."""
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = not task.get("completed", False)
                self._write()
                return True
        return False

    def set_complete(self, task_id: str, value: bool) -> bool:
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = value
                self._write()
                return True
        return False

    def delete_task(self, task_id: str) -> bool:
        before = len(self._tasks)
        self._tasks = [t for t in self._tasks if t["id"] != task_id]
        changed = len(self._tasks) < before
        if changed:
            self._write()
        return changed

    def move_up(self, task_id: str) -> None:
        tasks = self.get_all()
        for i, t in enumerate(tasks):
            if t["id"] == task_id and i > 0:
                tasks[i]["order"], tasks[i - 1]["order"] = (
                    tasks[i - 1]["order"],
                    tasks[i]["order"],
                )
                break
        self._tasks = tasks
        self._write()

    def move_down(self, task_id: str) -> None:
        tasks = self.get_all()
        for i, t in enumerate(tasks):
            if t["id"] == task_id and i < len(tasks) - 1:
                tasks[i]["order"], tasks[i + 1]["order"] = (
                    tasks[i + 1]["order"],
                    tasks[i]["order"],
                )
                break
        self._tasks = tasks
        self._write()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> list[dict[str, Any]]:
        try:
            if self._path.exists():
                with self._path.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        tasks = data.get("tasks", [])
                        if isinstance(tasks, list):
                            return tasks
        except (json.JSONDecodeError, OSError, ValueError):
            pass
        return []

    def _write(self) -> None:
        try:
            _DATA_DIR.mkdir(parents=True, exist_ok=True)
            tmp_path = self._path.with_suffix(".tmp")
            with tmp_path.open("w", encoding="utf-8") as f:
                json.dump({"tasks": self._tasks}, f, indent=2)
            os.replace(str(tmp_path), str(self._path))
        except OSError:
            try:
                with self._path.open("w", encoding="utf-8") as f:
                    json.dump({"tasks": self._tasks}, f, indent=2)
            except OSError:
                pass
