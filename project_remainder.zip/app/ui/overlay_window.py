"""
Session-review overlay window.

Appears always-on-top when a timer/stopwatch session finishes.
Lets the user rate productivity (1-5 stars), add notes, and
optionally mark tasks as completed.
Plays custom MP3 / system alarm sound and stops when reviewed.
"""
from __future__ import annotations

import time
import tkinter as tk
from tkinter import messagebox
from typing import TYPE_CHECKING, Callable

from ..core.audio_player import play_alarm, stop_sound
from .theme import (
    ACCENT, ACCENT_HV, BG, BORDER, CARD, CARD_HOVER, DANGER,
    FONT_BODY, FONT_BODY_B, FONT_H1, FONT_H2, FONT_H3,
    FONT_SMALL, FONT_TIMER_SM, SURFACE, TEXT, TEXT_MUT, WARN,
)
from .widgets import StarRating, btn, sep

if TYPE_CHECKING:
    from ..core.session_manager import SessionManager
    from ..core.settings_manager import SettingsManager
    from ..core.todo_manager import TodoManager


class OverlayWindow(tk.Toplevel):
    """
    Full-screen / large centred session-review dialog.
    """

    def __init__(
        self,
        root: tk.Tk,
        *,
        mode: str,
        elapsed: float,
        start_time: str,
        target: int | None,
        todo_enabled: bool,
        todo_manager: "TodoManager | None",
        session_mgr: "SessionManager",
        settings_mgr: "SettingsManager",
        on_done: Callable[[dict], None] | None = None,
    ) -> None:
        super().__init__(root)
        self._root = root
        self._mode = mode
        self._elapsed = elapsed
        self._start_time = start_time
        self._target = target
        self._todo_enabled = todo_enabled
        self._todo_mgr = todo_manager
        self._session_mgr = session_mgr
        self._settings_mgr = settings_mgr
        self._on_done = on_done

        self._rating = 0
        self._task_vars: dict[str, tk.BooleanVar] = {}

        self._setup_window()
        self._build()
        self._play_alarm_sound()

    # ------------------------------------------------------------------
    # Window setup
    # ------------------------------------------------------------------

    def _setup_window(self) -> None:
        self.title("Session Complete — Project Remainder")
        self.configure(bg=BG)
        self.resizable(False, False)
        self.attributes("-topmost", True)

        # Centre on screen
        self.update_idletasks()
        W, H = 560, 620
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x = (sw - W) // 2
        y = (sh - H) // 2
        self.geometry(f"{W}x{H}+{x}+{y}")

        # Prevent accidental close without saving
        self.protocol("WM_DELETE_WINDOW", self._on_close_without_save)
        try:
            self.grab_set()  # Modal
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------

    def _build() -> None:
        root_frame = tk.Frame(self, bg=BG, padx=32, pady=24)
        root_frame.pack(fill="both", expand=True)

        # ── Header ───────────────────────────────────────────────────
        hdr = tk.Frame(root_frame, bg=BG)
        hdr.pack(fill="x", pady=(0, 16))

        emoji = "⏰" if self._mode == "timer" else "⏱"
        tk.Label(hdr, text=f"{emoji}  Session Complete!",
                 font=FONT_H1, bg=BG, fg=ACCENT).pack(anchor="w")

        # Duration summary
        from ..core.stats_engine import fmt_duration, fmt_clock
        dur_str = fmt_duration(self._elapsed)
        clock_str = fmt_clock(self._elapsed)
        mode_label = "Timer" if self._mode == "timer" else "Stopwatch"
        summary = f"{mode_label} · {clock_str}  ({dur_str})"
        if self._mode == "timer" and self._target:
            pct = min(100, int(self._elapsed / self._target * 100))
            summary += f"  ·  {pct}% of goal"

        tk.Label(hdr, text=summary, font=FONT_BODY, bg=BG, fg=TEXT_MUT).pack(anchor="w", pady=(4, 0))

        sep(root_frame, bg=BORDER).pack(fill="x", pady=12)

        # Scrollable content area
        canvas = tk.Canvas(root_frame, bg=BG, highlightthickness=0)
        scrollbar = tk.Scrollbar(root_frame, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=BG)
        canvas_window = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _on_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(canvas_window, width=event.width)

        inner.bind("<Configure>", _on_configure)
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(canvas_window, width=e.width))

        # Mouse wheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(-1 * (event.delta // 120), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        # ── Rating ───────────────────────────────────────────────────
        rating_card = tk.Frame(inner, bg=CARD, padx=16, pady=14)
        rating_card.pack(fill="x", pady=(0, 10))

        tk.Label(rating_card, text="How productive was this session?",
                 font=FONT_H3, bg=CARD, fg=TEXT).pack(anchor="w")
        tk.Label(rating_card, text="Select a rating from 1 (low) to 5 (excellent).",
                 font=FONT_SMALL, bg=CARD, fg=TEXT_MUT).pack(anchor="w", pady=(2, 10))

        self._star_widget = StarRating(
            rating_card,
            on_change=self._on_rating,
            bg=CARD,
        )
        self._star_widget.pack(anchor="w")

        self._rating_hint = tk.Label(rating_card, text="Tap a star to rate",
                                      font=FONT_SMALL, bg=CARD, fg=TEXT_MUT)
        self._rating_hint.pack(anchor="w", pady=(6, 0))

        # ── Notes ────────────────────────────────────────────────────
        notes_card = tk.Frame(inner, bg=CARD, padx=16, pady=14)
        notes_card.pack(fill="x", pady=(0, 10))

        tk.Label(notes_card, text="What did you accomplish?",
                 font=FONT_H3, bg=CARD, fg=TEXT).pack(anchor="w")
        tk.Label(notes_card, text="Optional — jot down what you worked on.",
                 font=FONT_SMALL, bg=CARD, fg=TEXT_MUT).pack(anchor="w", pady=(2, 8))

        self._notes = tk.Text(
            notes_card,
            height=4,
            font=FONT_BODY,
            bg=SURFACE,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            bd=0,
            padx=10,
            pady=8,
            wrap="word",
        )
        self._notes.pack(fill="x")
        self._notes.insert("1.0", "")

        # ── Tasks ────────────────────────────────────────────────────
        if self._todo_enabled and self._todo_mgr:
            tasks = self._todo_mgr.get_incomplete()
            if tasks:
                tasks_card = tk.Frame(inner, bg=CARD, padx=16, pady=14)
                tasks_card.pack(fill="x", pady=(0, 10))

                tk.Label(tasks_card, text="Tasks completed this session?",
                         font=FONT_H3, bg=CARD, fg=TEXT).pack(anchor="w")
                tk.Label(tasks_card, text="Check any tasks you finished.",
                         font=FONT_SMALL, bg=CARD, fg=TEXT_MUT).pack(anchor="w", pady=(2, 8))

                for task in tasks:
                    tid = task["id"]
                    var = tk.BooleanVar(value=False)
                    self._task_vars[tid] = var
                    cb = tk.Checkbutton(
                        tasks_card,
                        text=task["text"],
                        variable=var,
                        font=FONT_BODY,
                        bg=CARD,
                        fg=TEXT,
                        selectcolor=SURFACE,
                        activebackground=CARD,
                        activeforeground=TEXT,
                        relief="flat",
                        anchor="w",
                        cursor="hand2",
                    )
                    cb.pack(fill="x", pady=2)

        # ── Action buttons ───────────────────────────────────────────
        sep(inner, bg=BORDER).pack(fill="x", pady=12)

        btn_row = tk.Frame(inner, bg=BG)
        btn_row.pack(fill="x")

        discard_b = btn(btn_row, "Discard", command=self._discard, style="ghost")
        discard_b.pack(side="right", padx=(8, 0))

        save_b = btn(btn_row, "Save Session", command=self._save, style="primary")
        save_b.pack(side="right")

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def _on_rating(self, value: int) -> None:
        self._rating = value
        labels = ["", "😕 Low productivity",
                  "🙁 Below average",
                  "😐 Average session",
                  "🙂 Good session",
                  "😄 Excellent session!"]
        if 0 <= value < len(labels):
            self._rating_hint.configure(text=labels[value], fg=ACCENT)

    def _save(self) -> None:
        stop_sound()
        try:
            notes_text = self._notes.get("1.0", "end-1c").strip()
            completed_task_ids = [tid for tid, var in self._task_vars.items() if var.get()]
            rating = max(1, self._rating) if self._rating > 0 else 3

            end_time = time.strftime("%H:%M:%S")
            start_time = self._start_time or time.strftime("%H:%M:%S")
            
            session = self._session_mgr.save_session(
                mode=self._mode,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=self._elapsed,
                target_duration=self._target,
                productivity_rating=rating,
                notes=notes_text,
                tasks_completed=completed_task_ids,
            )

            # Mark completed tasks in the todo manager
            if self._todo_mgr:
                for tid in completed_task_ids:
                    self._todo_mgr.set_complete(tid, True)

            self.unbind_all("<MouseWheel>")
            try:
                self.grab_release()
            except Exception:
                pass
            self.destroy()

            if self._on_done:
                self._on_done(session)
        except Exception as err:
            messagebox.showerror("Save Error", f"Failed to save session: {err}", parent=self)

    def _discard(self) -> None:
        stop_sound()
        self.unbind_all("<MouseWheel>")
        try:
            self.grab_release()
        except Exception:
            pass
        self.destroy()

    def _on_close_without_save(self) -> None:
        self._discard()

    def _play_alarm_sound(self) -> None:
        play_alarm(self._settings_mgr)
