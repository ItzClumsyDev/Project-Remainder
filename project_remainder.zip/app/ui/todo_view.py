"""
To-Do list view — simple task manager integrated with work sessions.

Features:
  • Scrollable task list with checkboxes
  • Add new task via entry + button
  • Inline edit task text (double-click)
  • Delete task button per row
  • Move up / Move down per row
  • Shows when todo_enabled = True in settings
"""
from __future__ import annotations

import tkinter as tk
from tkinter import simpledialog
from typing import TYPE_CHECKING

from .theme import (
    ACCENT, BG, BORDER, CARD, CARD_HOVER, FONT_BODY, FONT_BODY_B,
    FONT_H2, FONT_H3, FONT_SMALL, PAD, PAD_LG,
    STAR_ON, SURFACE, TEXT, TEXT_MUT, TEXT_HINT,
)
from .widgets import btn, sep

if TYPE_CHECKING:
    from ..core.todo_manager import TodoManager


class TodoView(tk.Frame):
    """To-Do list view."""

    def __init__(self, parent: tk.Widget, todo_mgr: "TodoManager") -> None:
        super().__init__(parent, bg=BG)
        self._todo_mgr = todo_mgr
        self._build()

    # ------------------------------------------------------------------

    def _build(self) -> None:
        # ── Header ───────────────────────────────────────────────────
        hdr = tk.Frame(self, bg=SURFACE, padx=PAD_LG, pady=12)
        hdr.pack(fill="x")
        tk.Label(hdr, text="To-Do List", font=FONT_H2, bg=SURFACE, fg=TEXT).pack(side="left")

        # ── Add task row ─────────────────────────────────────────────
        add_row = tk.Frame(self, bg=BG, padx=PAD_LG, pady=PAD)
        add_row.pack(fill="x")

        self._entry_var = tk.StringVar()
        self._entry = tk.Entry(
            add_row,
            textvariable=self._entry_var,
            font=FONT_BODY,
            bg=SURFACE,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            bd=0,
        )
        self._entry.pack(side="left", fill="x", expand=True, ipady=8, ipadx=8)
        self._entry.bind("<Return>", lambda _: self._add_task())

        add_btn = btn(add_row, "+ Add Task", command=self._add_task, style="primary")
        add_btn.pack(side="left", padx=(8, 0))

        sep(self, bg=BORDER).pack(fill="x")

        # ── Task list (scrollable) ────────────────────────────────────
        list_canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        sb = tk.Scrollbar(self, orient="vertical", command=list_canvas.yview)
        list_canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        list_canvas.pack(side="left", fill="both", expand=True)

        self._list_frame = tk.Frame(list_canvas, bg=BG, padx=PAD_LG, pady=PAD)
        self._win_id = list_canvas.create_window((0, 0), window=self._list_frame, anchor="nw")

        self._list_frame.bind(
            "<Configure>",
            lambda _: list_canvas.configure(scrollregion=list_canvas.bbox("all")),
        )
        list_canvas.bind(
            "<Configure>",
            lambda e: list_canvas.itemconfig(self._win_id, width=e.width),
        )
        list_canvas.bind_all(
            "<MouseWheel>",
            lambda e: list_canvas.yview_scroll(-1 * (e.delta // 120), "units"),
        )

        self._render_tasks()

    # ------------------------------------------------------------------

    def _add_task(self) -> None:
        text = self._entry_var.get().strip()
        if not text:
            return
        self._todo_mgr.add_task(text)
        self._entry_var.set("")
        self._entry.focus()
        self._render_tasks()

    def _render_tasks(self) -> None:
        for w in self._list_frame.winfo_children():
            w.destroy()

        tasks = self._todo_mgr.get_all()

        if not tasks:
            tk.Label(
                self._list_frame,
                text="No tasks yet. Add one above!",
                font=FONT_BODY, bg=BG, fg=TEXT_HINT,
            ).pack(pady=40)
            return

        # Group: incomplete then complete
        incomplete = [t for t in tasks if not t.get("completed")]
        complete   = [t for t in tasks if t.get("completed")]

        for t in incomplete:
            self._task_row(t, is_complete=False)

        if complete:
            sep(self._list_frame, bg=BORDER).pack(fill="x", pady=8)
            tk.Label(self._list_frame, text="Completed",
                     font=FONT_SMALL, bg=BG, fg=TEXT_MUT).pack(anchor="w", pady=(0, 4))
            for t in complete:
                self._task_row(t, is_complete=True)

    def _task_row(self, task: dict, is_complete: bool) -> None:
        row = tk.Frame(self._list_frame, bg=CARD, padx=10, pady=8)
        row.pack(fill="x", pady=(0, 4))

        # Checkbox
        var = tk.BooleanVar(value=is_complete)
        cb = tk.Checkbutton(
            row,
            variable=var,
            bg=CARD,
            activebackground=CARD,
            selectcolor=SURFACE,
            relief="flat",
            cursor="hand2",
            command=lambda tid=task["id"]: self._toggle(tid),
        )
        cb.pack(side="left")

        # Task text
        text_color = TEXT_MUT if is_complete else TEXT
        text_font  = (FONT_BODY[0], FONT_BODY[1], "overstrike") if is_complete else FONT_BODY

        lbl = tk.Label(
            row,
            text=task["text"],
            font=text_font,
            bg=CARD,
            fg=text_color,
            anchor="w",
            cursor="hand2",
        )
        lbl.pack(side="left", fill="x", expand=True, padx=(4, 0))
        lbl.bind("<Double-Button-1>", lambda e, tid=task["id"], t=task["text"]: self._edit(tid, t))

        # Action buttons (right side)
        action_frame = tk.Frame(row, bg=CARD)
        action_frame.pack(side="right")

        for symbol, cmd in [
            ("▲", lambda tid=task["id"]: self._move(tid, "up")),
            ("▼", lambda tid=task["id"]: self._move(tid, "down")),
            ("✎", lambda tid=task["id"], t=task["text"]: self._edit(tid, t)),
            ("✕", lambda tid=task["id"]: self._delete(tid)),
        ]:
            b = tk.Button(
                action_frame,
                text=symbol,
                font=("Segoe UI", 9),
                bg=CARD,
                fg=TEXT_MUT,
                activebackground=CARD_HOVER,
                activeforeground=TEXT,
                relief="flat",
                bd=0,
                padx=4,
                cursor="hand2",
                command=cmd,
            )
            b.pack(side="left")

    # ------------------------------------------------------------------

    def _toggle(self, task_id: str) -> None:
        self._todo_mgr.toggle_complete(task_id)
        self._render_tasks()

    def _edit(self, task_id: str, current_text: str) -> None:
        new_text = simpledialog.askstring(
            "Edit Task",
            "Task text:",
            initialvalue=current_text,
            parent=self,
        )
        if new_text and new_text.strip():
            self._todo_mgr.update_text(task_id, new_text.strip())
            self._render_tasks()

    def _delete(self, task_id: str) -> None:
        self._todo_mgr.delete_task(task_id)
        self._render_tasks()

    def _move(self, task_id: str, direction: str) -> None:
        if direction == "up":
            self._todo_mgr.move_up(task_id)
        else:
            self._todo_mgr.move_down(task_id)
        self._render_tasks()

    def refresh(self) -> None:
        """Re-render task list (e.g., after overlay marks tasks complete)."""
        self._render_tasks()
