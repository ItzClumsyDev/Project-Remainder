"""
Shared reusable UI widgets for Project Remainder.

Provides:
- card()         — styled Frame acting as a card container
- heading()      — styled heading Label
- label()        — body/muted Label
- sep()          — thin horizontal separator
- btn()          — styled flat button
- TimerRing      — Canvas-based circular progress ring
- StarRating     — interactive 1–5 star selector
- BarChart       — Canvas bar chart
- LineChart      — Canvas line chart
"""
from __future__ import annotations

import math
import tkinter as tk
from typing import Callable

from .theme import (
    ACCENT, ACCENT_HV, BG, BORDER, BORDER_LT, CARD, CARD_HOVER, DANGER,
    FONT_BODY, FONT_BODY_B, FONT_H1, FONT_H2, FONT_H3, FONT_SMALL,
    FONT_TIMER_LG, FONT_TIMER_MD, FONT_TINY,
    RING_BG, RING_CRIT, RING_FG, RING_WARN, STAR_OFF, STAR_ON,
    SURFACE, TEXT, TEXT_MUT, TEXT_HINT, WARN,
)


# ---------------------------------------------------------------------------
# Simple widget factories
# ---------------------------------------------------------------------------

def card(parent: tk.Widget, **kwargs) -> tk.Frame:
    kw = dict(bg=CARD, relief="flat", bd=0)
    kw.update(kwargs)
    return tk.Frame(parent, **kw)


def heading(parent: tk.Widget, text: str, size: str = "h2", **kwargs) -> tk.Label:
    font_map = {"h1": FONT_H1, "h2": FONT_H2, "h3": FONT_H3}
    kw = dict(bg=CARD, fg=TEXT, font=font_map.get(size, FONT_H2), anchor="w")
    kw.update(kwargs)
    return tk.Label(parent, text=text, **kw)


def label(parent: tk.Widget, text: str, muted: bool = False, **kwargs) -> tk.Label:
    kw = dict(bg=CARD, fg=TEXT_MUT if muted else TEXT, font=FONT_BODY, anchor="w")
    kw.update(kwargs)
    return tk.Label(parent, text=text, **kw)


def sep(parent: tk.Widget, **kwargs) -> tk.Frame:
    kw = dict(bg=BORDER, height=1)
    kw.update(kwargs)
    return tk.Frame(parent, **kw)


def btn(
    parent: tk.Widget,
    text: str,
    command: Callable | None = None,
    style: str = "primary",
    **kwargs,
) -> tk.Button:
    """
    style: 'primary' | 'secondary' | 'danger' | 'ghost'
    """
    styles = {
        "primary":   dict(bg=ACCENT,   fg=TEXT,     activebackground=ACCENT_HV, activeforeground=TEXT),
        "secondary": dict(bg=CARD,     fg=TEXT,     activebackground=CARD_HOVER, activeforeground=TEXT),
        "danger":    dict(bg=DANGER,   fg=TEXT,     activebackground="#c23b31",  activeforeground=TEXT),
        "ghost":     dict(bg=SURFACE,  fg=TEXT_MUT, activebackground=CARD,       activeforeground=TEXT),
    }
    s = styles.get(style, styles["primary"])
    kw = dict(relief="flat", bd=0, cursor="hand2", font=FONT_BODY_B,
              padx=16, pady=8, **s)
    kw.update(kwargs)
    b = tk.Button(parent, text=text, command=command, **kw)
    # Subtle hover effect
    orig_bg = kw["bg"]
    hover_bg = kw["activebackground"]
    b.bind("<Enter>", lambda _: b.configure(bg=hover_bg))
    b.bind("<Leave>", lambda _: b.configure(bg=orig_bg))
    return b


# ---------------------------------------------------------------------------
# TimerRing — circular countdown / stopwatch display
# ---------------------------------------------------------------------------

class TimerRing(tk.Canvas):
    """
    Canvas widget that draws a circular progress arc.

    Call update_timer(elapsed, total) or update_stopwatch(elapsed)
    to refresh the display.
    """

    SIZE = 300
    RING_W = 14

    def __init__(self, parent: tk.Widget, bg_color: str = BG, **kwargs) -> None:
        super().__init__(
            parent,
            width=self.SIZE,
            height=self.SIZE,
            bg=bg_color,
            highlightthickness=0,
            **kwargs,
        )
        self._elapsed = 0.0
        self._total = 0.0
        self._mode: str = "idle"      # 'idle' | 'timer' | 'stopwatch'
        self._paused = False
        self._bg_color = bg_color
        self._draw()

    # Public update methods ---------------------------------------------------

    def update_timer(self, elapsed: float, total: float, paused: bool = False) -> None:
        self._elapsed = elapsed
        self._total = total
        self._mode = "timer"
        self._paused = paused
        self._draw()

    def update_stopwatch(self, elapsed: float, paused: bool = False) -> None:
        self._elapsed = elapsed
        self._mode = "stopwatch"
        self._paused = paused
        self._draw()

    def reset(self) -> None:
        self._elapsed = 0.0
        self._total = 0.0
        self._mode = "idle"
        self._paused = False
        self._draw()

    # Internal drawing --------------------------------------------------------

    def _draw(self) -> None:
        self.delete("all")
        cx = cy = self.SIZE // 2
        r = cx - self.RING_W - 10
        rw = self.RING_W

        x0, y0 = cx - r, cy - r
        x1, y1 = cx + r, cy + r

        # Background ring (full circle)
        self.create_arc(
            x0, y0, x1, y1,
            start=0, extent=359.99,
            style="arc", outline=RING_BG, width=rw,
        )

        time_str = "00:00"
        sub_str = "Ready to start"
        ring_color = RING_FG

        if self._mode == "timer" and self._total > 0:
            progress = min(self._elapsed / self._total, 1.0)
            remaining = max(0.0, self._total - self._elapsed)
            remaining_ratio = 1.0 - progress

            if remaining_ratio <= 0.10:
                ring_color = RING_CRIT
            elif remaining_ratio <= 0.20:
                ring_color = RING_WARN
            else:
                ring_color = RING_FG

            if progress > 0.001:
                extent = -359.99 * progress  # clockwise
                self.create_arc(
                    x0, y0, x1, y1,
                    start=90, extent=extent,
                    style="arc", outline=ring_color, width=rw,
                )

            time_str = _fmt_clock(remaining)
            pct = int(progress * 100)
            sub_str = f"{'⏸ Paused  ' if self._paused else ''}{pct}% complete"

        elif self._mode == "stopwatch":
            # Rotating loop: full circle every 60 s
            loop_prog = (self._elapsed % 60.0) / 60.0
            if loop_prog > 0.001:
                extent = -359.99 * loop_prog
                self.create_arc(
                    x0, y0, x1, y1,
                    start=90, extent=extent,
                    style="arc", outline=RING_FG, width=rw,
                )
            time_str = _fmt_elapsed(self._elapsed)
            sub_str = "⏸ Paused" if self._paused else "Elapsed time"

        else:
            # Idle — draw a dim partial arc for visual interest
            self.create_arc(
                x0, y0, x1, y1,
                start=90, extent=-90,
                style="arc", outline=RING_BG, width=rw,
            )

        # Glowing dot at arc tip (timer mode only)
        if self._mode == "timer" and self._total > 0 and 0.001 < (self._elapsed / self._total) < 0.999:
            progress = self._elapsed / self._total
            angle = math.radians(90 - 360 * progress)
            dx = r * math.cos(angle)
            dy = -r * math.sin(angle)
            self.create_oval(
                cx + dx - 6, cy + dy - 6,
                cx + dx + 6, cy + dy + 6,
                fill=ring_color, outline="",
            )

        # Center time text
        self.create_text(
            cx, cy - 18,
            text=time_str,
            font=FONT_TIMER_LG if len(time_str) <= 5 else FONT_TIMER_MD,
            fill=TEXT,
            anchor="center",
        )

        # Subtitle
        self.create_text(
            cx, cy + 22,
            text=sub_str,
            font=FONT_SMALL,
            fill=TEXT_MUT,
            anchor="center",
        )


# ---------------------------------------------------------------------------
# StarRating — interactive 1–5 star selector
# ---------------------------------------------------------------------------

class StarRating(tk.Frame):
    """
    Interactive star rating widget (1–5 stars).
    on_change(value) is called when the rating changes.
    """

    def __init__(
        self,
        parent: tk.Widget,
        on_change: Callable[[int], None] | None = None,
        initial: int = 0,
        bg: str = CARD,
        **kwargs,
    ) -> None:
        super().__init__(parent, bg=bg, **kwargs)
        self._value = initial
        self._hover_value = 0
        self._on_change = on_change
        self._bg = bg
        self._stars: list[tk.Label] = []
        self._build()
        self._draw()

    def _build(self) -> None:
        for i in range(1, 6):
            lbl = tk.Label(
                self,
                text="★",
                font=("Segoe UI", 22),
                bg=self._bg,
                fg=STAR_OFF,
                cursor="hand2",
                padx=2,
            )
            lbl.grid(row=0, column=i - 1)
            lbl.bind("<Button-1>", lambda e, v=i: self._click(v))
            lbl.bind("<Enter>",    lambda e, v=i: self._on_enter(v))
            lbl.bind("<Leave>",    lambda e:       self._on_leave())
            self._stars.append(lbl)

    def _click(self, value: int) -> None:
        self._value = value
        self._draw()
        if self._on_change:
            self._on_change(value)

    def _on_enter(self, value: int) -> None:
        self._hover_value = value
        for i, s in enumerate(self._stars):
            s.configure(fg=STAR_ON if i < value else STAR_OFF)

    def _on_leave(self) -> None:
        self._hover_value = 0
        self._draw()

    def _draw(self) -> None:
        for i, s in enumerate(self._stars):
            s.configure(fg=STAR_ON if i < self._value else STAR_OFF)

    def get(self) -> int:
        return self._value

    def set(self, value: int) -> None:
        self._value = max(0, min(5, value))
        self._draw()


# ---------------------------------------------------------------------------
# BarChart — Canvas bar chart
# ---------------------------------------------------------------------------

class BarChart(tk.Canvas):
    """Simple bar chart for daily session minutes."""

    def __init__(self, parent: tk.Widget, height: int = 160, **kwargs) -> None:
        kw = dict(bg=CARD, highlightthickness=0, height=height)
        kw.update(kwargs)
        super().__init__(parent, **kw)
        self._data: list[tuple[str, float]] = []
        self.bind("<Configure>", lambda _: self._draw())

    def set_data(self, data: list[tuple[str, float]]) -> None:
        """data: list of (label, value) pairs."""
        self._data = data
        self._draw()

    def _draw(self) -> None:
        self.delete("all")
        w = self.winfo_width() or 400
        h = self.winfo_height() or 160

        if not self._data:
            self.create_text(w // 2, h // 2, text="No data yet",
                             font=FONT_SMALL, fill=TEXT_HINT)
            return

        ML, MR, MT, MB = 50, 16, 12, 32  # margins
        cw = w - ML - MR
        ch = h - MT - MB

        max_val = max(v for _, v in self._data) or 1.0
        n = len(self._data)
        slot_w = cw / n
        bar_w = max(4.0, slot_w * 0.55)

        # Gridlines (3 horizontal)
        for frac in (0.25, 0.5, 0.75, 1.0):
            y = MT + ch - ch * frac
            self.create_line(ML, y, ML + cw, y, fill=BORDER, dash=(3, 4))
            val = max_val * frac
            self.create_text(ML - 4, y, text=f"{val:.0f}",
                             font=FONT_TINY, fill=TEXT_HINT, anchor="e")

        # Bars
        for i, (lbl, val) in enumerate(self._data):
            x_center = ML + slot_w * i + slot_w / 2
            bh = (val / max_val) * ch if max_val else 0
            x0 = x_center - bar_w / 2
            y0 = MT + ch - bh
            x1 = x_center + bar_w / 2
            y1 = MT + ch

            # Bar fill
            color = ACCENT if val > 0 else BORDER
            self.create_rectangle(x0, y0, x1, y1, fill=color, outline="")

            # Value label above bar
            if val > 0:
                self.create_text(
                    x_center, y0 - 4,
                    text=f"{val:.0f}",
                    font=FONT_TINY, fill=TEXT_MUT, anchor="s",
                )

            # X-axis label
            self.create_text(
                x_center, h - MB + 10,
                text=lbl,
                font=FONT_TINY, fill=TEXT_MUT,
            )

        # Axes
        self.create_line(ML, MT, ML, MT + ch, fill=BORDER)
        self.create_line(ML, MT + ch, ML + cw, MT + ch, fill=BORDER)


# ---------------------------------------------------------------------------
# LineChart — Canvas productivity trend line
# ---------------------------------------------------------------------------

class LineChart(tk.Canvas):
    """Simple line chart for productivity rating trend."""

    def __init__(self, parent: tk.Widget, height: int = 130, **kwargs) -> None:
        kw = dict(bg=CARD, highlightthickness=0, height=height)
        kw.update(kwargs)
        super().__init__(parent, **kw)
        self._data: list[tuple[str, float]] = []
        self._max_y = 5.0
        self.bind("<Configure>", lambda _: self._draw())

    def set_data(self, data: list[tuple[str, float]], max_y: float = 5.0) -> None:
        self._data = data
        self._max_y = max_y
        self._draw()

    def _draw(self) -> None:
        self.delete("all")
        w = self.winfo_width() or 400
        h = self.winfo_height() or 130

        if not self._data:
            self.create_text(w // 2, h // 2, text="No data yet",
                             font=FONT_SMALL, fill=TEXT_HINT)
            return

        ML, MR, MT, MB = 40, 16, 10, 28
        cw = w - ML - MR
        ch = h - MT - MB
        n = len(self._data)

        def px(i: int) -> float:
            return ML + (i / max(n - 1, 1)) * cw

        def py(v: float) -> float:
            return MT + ch - (v / self._max_y) * ch if self._max_y else MT + ch

        # Gridline at rating 3 and 5
        for val in (1, 2, 3, 4, 5):
            y = py(val)
            self.create_line(ML, y, ML + cw, y, fill=BORDER, dash=(2, 5))
            self.create_text(ML - 4, y, text=str(val),
                             font=FONT_TINY, fill=TEXT_HINT, anchor="e")

        # Area fill (polygon under the line)
        has_data = any(v > 0 for _, v in self._data)
        if has_data and n > 1:
            pts: list[float] = []
            for i, (_, v) in enumerate(self._data):
                pts += [px(i), py(v)]
            # Close polygon at bottom
            pts += [px(n - 1), MT + ch, px(0), MT + ch]
            self.create_polygon(pts, fill="#1a3a1a", outline="")

        # Line segments and dots
        prev: tuple[float, float] | None = None
        for i, (lbl, v) in enumerate(self._data):
            x, y = px(i), py(v)
            if prev and v > 0:
                self.create_line(*prev, x, y, fill=ACCENT, width=2, smooth=True)
            if v > 0:
                self.create_oval(x - 4, y - 4, x + 4, y + 4,
                                 fill=ACCENT, outline=CARD, width=2)
            prev = (x, y) if v > 0 else None

            # X labels
            self.create_text(x, h - MB + 10, text=lbl,
                             font=FONT_TINY, fill=TEXT_MUT)

        # Axes
        self.create_line(ML, MT, ML, MT + ch, fill=BORDER)
        self.create_line(ML, MT + ch, ML + cw, MT + ch, fill=BORDER)


# ---------------------------------------------------------------------------
# Shared formatting helpers (also used in views)
# ---------------------------------------------------------------------------

def _fmt_clock(seconds: float) -> str:
    """Format as MM:SS (or HH:MM:SS if >= 1 hour)."""
    s = max(0, int(seconds))
    h, rem = divmod(s, 3600)
    m, sc = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{sc:02d}" if h else f"{m:02d}:{sc:02d}"


def _fmt_elapsed(seconds: float) -> str:
    """Always HH:MM:SS."""
    s = max(0, int(seconds))
    h, rem = divmod(s, 3600)
    m, sc = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{sc:02d}"
