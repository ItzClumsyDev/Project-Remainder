"""
Dashboard view — the home screen of Project Remainder.

Shows:
  • Greeting + current date
  • Today's session stats (sessions, total time, avg rating)
  • Quick-start buttons (common timer durations + stopwatch)
  • Last 5 completed sessions
"""
from __future__ import annotations

import tkinter as tk
from datetime import datetime
from typing import TYPE_CHECKING, Callable

from .theme import (
    ACCENT, BG, BORDER, CARD, CARD_HOVER, FONT_BODY, FONT_BODY_B,
    FONT_H1, FONT_H2, FONT_H3, FONT_SMALL, FONT_TINY,
    FONT_TIMER_SM, PAD, PAD_LG, SURFACE, TEXT, TEXT_MUT, WARN,
    SUCCESS, STAR_ON,
)
from .widgets import btn, card, sep

if TYPE_CHECKING:
    from ..core.session_manager import SessionManager
    from ..core.stats_engine import compute_stats, filter_sessions, fmt_duration, readable_date


class DashboardView(tk.Frame):
    """Home screen — quick overview and fast session start."""

    def __init__(
        self,
        parent: tk.Widget,
        session_mgr: "SessionManager",
        on_start_timer: Callable[[int], None],
        on_start_stopwatch: Callable[[], None],
    ) -> None:
        super().__init__(parent, bg=BG)
        self._session_mgr = session_mgr
        self._on_start_timer = on_start_timer
        self._on_start_stopwatch = on_start_stopwatch
        self._build()

    # ------------------------------------------------------------------

    def _build(self) -> None:
        # Scrollable wrapper
        canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        sb = tk.Scrollbar(self, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=BG)
        win_id = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _resize(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(win_id, width=e.width)

        inner.bind("<Configure>", _resize)
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win_id, width=e.width))
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units"))

        p = tk.Frame(inner, bg=BG, padx=PAD_LG, pady=PAD_LG)
        p.pack(fill="both", expand=True)

        self._content = p
        self._refresh(p)

    def _refresh(self, p: tk.Frame) -> None:
        for w in p.winfo_children():
            w.destroy()

        from ..core.stats_engine import compute_stats, filter_sessions, fmt_duration, readable_date

        all_sessions = self._session_mgr.get_all()
        today_sessions = filter_sessions(all_sessions, "today")
        stats = compute_stats(today_sessions)

        # ── Greeting ─────────────────────────────────────────────────
        now = datetime.now()
        hour = now.hour
        if hour < 12:
            greet = "Good morning"
        elif hour < 17:
            greet = "Good afternoon"
        else:
            greet = "Good evening"

        date_str = now.strftime("%A, %d %B %Y")

        tk.Label(p, text=greet, font=FONT_H1, bg=BG, fg=TEXT).pack(anchor="w")
        tk.Label(p, text=date_str, font=FONT_BODY, bg=BG, fg=TEXT_MUT).pack(anchor="w", pady=(2, 16))

        # ── Today's stat cards ────────────────────────────────────────
        stats_row = tk.Frame(p, bg=BG)
        stats_row.pack(fill="x", pady=(0, 20))
        stats_row.columnconfigure((0, 1, 2), weight=1, uniform="stat")

        def stat_card(parent, value, sub, color=TEXT):
            f = tk.Frame(parent, bg=CARD, padx=16, pady=14)
            tk.Label(f, text=value, font=FONT_H1, bg=CARD, fg=color).pack(anchor="w")
            tk.Label(f, text=sub, font=FONT_SMALL, bg=CARD, fg=TEXT_MUT).pack(anchor="w", pady=(2, 0))
            return f

        total_secs = stats["total_seconds"]
        n_sessions = stats["total_sessions"]
        avg_rating = stats["avg_rating"]

        card0 = stat_card(stats_row, str(n_sessions), "Sessions today")
        card0.grid(row=0, column=0, sticky="nsew", padx=(0, 6))

        dur_str = fmt_duration(total_secs) if total_secs else "0m"
        card1 = stat_card(stats_row, dur_str, "Total time today", ACCENT)
        card1.grid(row=0, column=1, sticky="nsew", padx=6)

        rating_str = f"{avg_rating}/5" if avg_rating else "—"
        card2 = stat_card(stats_row, rating_str, "Avg productivity", WARN if avg_rating else TEXT_MUT)
        card2.grid(row=0, column=2, sticky="nsew", padx=(6, 0))

        # ── Quick-start ───────────────────────────────────────────────
        tk.Label(p, text="Quick Start", font=FONT_H2, bg=BG, fg=TEXT).pack(anchor="w", pady=(0, 8))

        qs_frame = tk.Frame(p, bg=BG)
        qs_frame.pack(fill="x", pady=(0, 20))

        presets = [("15 min", 15 * 60), ("25 min", 25 * 60),
                   ("40 min", 40 * 60), ("60 min", 60 * 60)]

        for label, secs in presets:
            b = btn(qs_frame, label,
                    command=lambda s=secs: self._on_start_timer(s),
                    style="secondary")
            b.pack(side="left", padx=(0, 8))

        sw_btn = btn(qs_frame, "Stopwatch",
                     command=self._on_start_stopwatch, style="ghost")
        sw_btn.pack(side="left")

        # ── Recent sessions ───────────────────────────────────────────
        tk.Label(p, text="Recent Sessions", font=FONT_H2, bg=BG, fg=TEXT).pack(anchor="w", pady=(0, 8))

        recent = list(reversed(all_sessions))[:5]
        if not recent:
            empty = tk.Frame(p, bg=CARD, padx=20, pady=20)
            empty.pack(fill="x")
            tk.Label(empty, text="No sessions yet. Start your first timer!",
                     font=FONT_BODY, bg=CARD, fg=TEXT_MUT).pack()
        else:
            for s in recent:
                self._session_row(p, s)

    def _session_row(self, parent: tk.Frame, s: dict) -> None:
        from ..core.stats_engine import fmt_duration, readable_date

        row = tk.Frame(parent, bg=CARD, padx=14, pady=10)
        row.pack(fill="x", pady=(0, 4))

        left = tk.Frame(row, bg=CARD)
        left.pack(side="left", fill="x", expand=True)

        mode_icon = "⏱" if s.get("mode") == "timer" else "⏱"
        notes = s.get("notes") or "No notes"
        if len(notes) > 60:
            notes = notes[:57] + "…"

        tk.Label(left, text=f"{readable_date(s.get('date',''))}  ·  {fmt_duration(s.get('duration_seconds',0))}",
                 font=FONT_BODY_B, bg=CARD, fg=TEXT).pack(anchor="w")
        tk.Label(left, text=notes, font=FONT_SMALL, bg=CARD, fg=TEXT_MUT).pack(anchor="w", pady=(2, 0))

        # Stars
        rating = s.get("productivity_rating", 0)
        stars = "★" * rating + "☆" * (5 - rating)
        tk.Label(row, text=stars, font=("Segoe UI", 11), bg=CARD, fg=STAR_ON).pack(side="right")

    def refresh(self) -> None:
        """Called by app_window after a session is saved."""
        self._refresh(self._content)
