"""
Timer view — countdown timer with circular progress ring.

Features:
  • Preset duration buttons (15 / 25 / 40 / 60 / 90 min)
  • Custom duration entry (minutes)
  • Circular progress ring with colour feedback
  • Start / Pause / Stop controls
"""
from __future__ import annotations

import tkinter as tk
from tkinter import messagebox
from typing import TYPE_CHECKING, Callable

from .theme import (
    ACCENT, BG, BORDER, CARD, FONT_BODY, FONT_BODY_B,
    FONT_H2, FONT_H3, FONT_SMALL, PAD, PAD_LG, SURFACE,
    TEXT, TEXT_MUT, WARN,
)
from .widgets import TimerRing, btn, sep

if TYPE_CHECKING:
    from ..core.timer_engine import TimerEngine


class TimerView(tk.Frame):
    """
    Countdown timer view.

    on_start(seconds)  — called when user starts the timer
    on_pause()         — called to pause/resume
    on_stop()          — called to stop and discard
    """

    PRESETS = [
        ("15 min", 15 * 60),
        ("25 min", 25 * 60),
        ("40 min", 40 * 60),
        ("60 min", 60 * 60),
        ("90 min", 90 * 60),
    ]

    def __init__(
        self,
        parent: tk.Widget,
        on_start: Callable[[int], None],
        on_pause: Callable[[], None],
        on_stop: Callable[[], None],
        default_minutes: int = 25,
    ) -> None:
        super().__init__(parent, bg=BG)
        self._on_start = on_start
        self._on_pause = on_pause
        self._on_stop = on_stop
        self._default_minutes = default_minutes
        self._selected_preset: int | None = None
        self._preset_btns: list[tk.Button] = []
        self._state = "idle"   # 'idle' | 'running' | 'paused'
        self._build()

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def _build(self) -> None:
        outer = tk.Frame(self, bg=BG)
        outer.place(relx=0.5, rely=0.5, anchor="center")

        # ── Title ────────────────────────────────────────────────────
        tk.Label(outer, text="Timer", font=FONT_H2, bg=BG, fg=TEXT).pack(pady=(0, 4))
        tk.Label(outer, text="Set a duration and focus on your work.",
                 font=FONT_SMALL, bg=BG, fg=TEXT_MUT).pack(pady=(0, 20))

        # ── Preset buttons ────────────────────────────────────────────
        preset_row = tk.Frame(outer, bg=BG)
        preset_row.pack(pady=(0, 20))

        for label, secs in self.PRESETS:
            b = tk.Button(
                preset_row,
                text=label,
                font=FONT_SMALL,
                bg=CARD,
                fg=TEXT_MUT,
                activebackground=ACCENT,
                activeforeground=TEXT,
                relief="flat",
                bd=0,
                padx=12,
                pady=6,
                cursor="hand2",
                command=lambda s=secs, lbl=label: self._select_preset(s, lbl),
            )
            b.pack(side="left", padx=4)
            self._preset_btns.append(b)

        # ── Ring ──────────────────────────────────────────────────────
        self._ring = TimerRing(outer, bg_color=BG)
        self._ring.pack(pady=(0, 20))

        # ── Custom duration ───────────────────────────────────────────
        custom_row = tk.Frame(outer, bg=BG)
        custom_row.pack(pady=(0, 24))

        tk.Label(custom_row, text="Custom (min):",
                 font=FONT_BODY, bg=BG, fg=TEXT_MUT).pack(side="left", padx=(0, 8))

        self._custom_var = tk.StringVar(value=str(self._default_minutes))
        self._custom_entry = tk.Entry(
            custom_row,
            textvariable=self._custom_var,
            font=FONT_BODY,
            bg=SURFACE,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            bd=0,
            width=5,
            justify="center",
        )
        self._custom_entry.pack(side="left", ipady=6, ipadx=4)
        self._custom_entry.bind("<FocusIn>",  lambda _: self._deselect_presets())
        self._custom_entry.bind("<Return>",   lambda _: self._on_start_click())

        # ── Control buttons ───────────────────────────────────────────
        ctrl_row = tk.Frame(outer, bg=BG)
        ctrl_row.pack()

        self._start_btn = btn(ctrl_row, "Start", command=self._on_start_click, style="primary")
        self._start_btn.pack(side="left", padx=(0, 8))

        self._pause_btn = btn(ctrl_row, "Pause", command=self._on_pause_click, style="secondary")
        self._pause_btn.pack(side="left", padx=(0, 8))
        self._pause_btn.configure(state="disabled")

        self._stop_btn = btn(ctrl_row, "Stop", command=self._on_stop_click, style="danger")
        self._stop_btn.pack(side="left")
        self._stop_btn.configure(state="disabled")

        # Select default preset visually
        self._select_preset_by_secs(self._default_minutes * 60)

    # ------------------------------------------------------------------
    # Interaction
    # ------------------------------------------------------------------

    def _select_preset(self, secs: int, label: str) -> None:
        self._selected_preset = secs
        mins = secs // 60
        self._custom_var.set(str(mins))
        self._highlight_presets(secs)

    def _select_preset_by_secs(self, secs: int) -> None:
        for s in [s for _, s in self.PRESETS]:
            if s == secs:
                self._select_preset(secs, "")
                return

    def _highlight_presets(self, active_secs: int) -> None:
        for i, (_, s) in enumerate(self.PRESETS):
            b = self._preset_btns[i]
            if s == active_secs:
                b.configure(bg=ACCENT, fg=TEXT)
            else:
                b.configure(bg=CARD, fg=TEXT_MUT)

    def _deselect_presets(self) -> None:
        self._selected_preset = None
        for b in self._preset_btns:
            b.configure(bg=CARD, fg=TEXT_MUT)

    def _get_seconds(self) -> int | None:
        try:
            mins = float(self._custom_var.get().strip())
            if mins <= 0:
                raise ValueError
            return int(mins * 60)
        except ValueError:
            messagebox.showerror(
                "Invalid Duration",
                "Please enter a positive number of minutes (e.g. 25).",
                parent=self,
            )
            return None

    def _on_start_click(self) -> None:
        if self._state == "idle":
            secs = self._get_seconds()
            if secs:
                self._on_start(secs)
                self._set_state("running")
        # If already running, do nothing (use pause/stop)

    def _on_pause_click(self) -> None:
        self._on_pause()
        new_state = "paused" if self._state == "running" else "running"
        self._set_state(new_state)

    def _on_stop_click(self) -> None:
        self._on_stop()
        self._set_state("idle")
        self._ring.reset()

    def _set_state(self, state: str) -> None:
        self._state = state
        if state == "idle":
            self._start_btn.configure(state="normal",  text="Start")
            self._pause_btn.configure(state="disabled", text="Pause")
            self._stop_btn.configure(state="disabled")
            self._custom_entry.configure(state="normal")
            for b in self._preset_btns:
                b.configure(state="normal")
        elif state == "running":
            self._start_btn.configure(state="disabled", text="Running…")
            self._pause_btn.configure(state="normal",  text="Pause")
            self._stop_btn.configure(state="normal")
            self._custom_entry.configure(state="disabled")
            for b in self._preset_btns:
                b.configure(state="disabled")
        elif state == "paused":
            self._start_btn.configure(state="disabled", text="Paused")
            self._pause_btn.configure(state="normal",  text="Resume")
            self._stop_btn.configure(state="normal")

    # ------------------------------------------------------------------
    # Called by app_window from the event queue
    # ------------------------------------------------------------------

    def on_tick(self, elapsed: float, total: float, paused: bool) -> None:
        self._ring.update_timer(elapsed, total, paused)

    def on_finish(self) -> None:
        self._set_state("idle")
        self._ring.reset()

    def set_default_minutes(self, minutes: int) -> None:
        self._default_minutes = minutes
        if self._state == "idle":
            self._custom_var.set(str(minutes))
            self._select_preset_by_secs(minutes * 60)
