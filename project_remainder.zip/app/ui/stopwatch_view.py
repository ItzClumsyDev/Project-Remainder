"""
Stopwatch view — tracks elapsed time without a fixed deadline.

Features:
  • Large HH:MM:SS elapsed display via TimerRing
  • Start / Pause / Resume / Stop & Save controls
  • Current elapsed time always visible in the ring
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable

from .theme import (
    ACCENT, BG, BORDER, CARD, FONT_BODY, FONT_BODY_B,
    FONT_H2, FONT_SMALL, PAD_LG, SURFACE, TEXT, TEXT_MUT,
)
from .widgets import TimerRing, btn, sep


class StopwatchView(tk.Frame):
    """
    Stopwatch mode view.

    Callbacks
    ---------
    on_start()   — user pressed Start
    on_pause()   — user pressed Pause / Resume
    on_stop()    — user pressed Stop & Save (triggers overlay in app_window)
    """

    def __init__(
        self,
        parent: tk.Widget,
        on_start: Callable[[], None],
        on_pause: Callable[[], None],
        on_stop: Callable[[], None],
    ) -> None:
        super().__init__(parent, bg=BG)
        self._on_start = on_start
        self._on_pause = on_pause
        self._on_stop = on_stop
        self._state = "idle"   # 'idle' | 'running' | 'paused'
        self._build()

    # ------------------------------------------------------------------

    def _build(self) -> None:
        outer = tk.Frame(self, bg=BG)
        outer.place(relx=0.5, rely=0.5, anchor="center")

        # ── Title ────────────────────────────────────────────────────
        tk.Label(outer, text="Stopwatch", font=FONT_H2, bg=BG, fg=TEXT).pack(pady=(0, 4))
        tk.Label(outer, text="Track your work time freely — stop when you're done.",
                 font=FONT_SMALL, bg=BG, fg=TEXT_MUT).pack(pady=(0, 20))

        # ── Ring ──────────────────────────────────────────────────────
        self._ring = TimerRing(outer, bg_color=BG)
        self._ring.pack(pady=(0, 28))

        # ── Hint ──────────────────────────────────────────────────────
        self._hint = tk.Label(outer, text="Press Start to begin tracking your session.",
                              font=FONT_SMALL, bg=BG, fg=TEXT_MUT)
        self._hint.pack(pady=(0, 20))

        # ── Controls ─────────────────────────────────────────────────
        ctrl_row = tk.Frame(outer, bg=BG)
        ctrl_row.pack()

        self._start_btn = btn(ctrl_row, "Start", command=self._on_start_click, style="primary")
        self._start_btn.pack(side="left", padx=(0, 8))

        self._pause_btn = btn(ctrl_row, "Pause", command=self._on_pause_click, style="secondary")
        self._pause_btn.pack(side="left", padx=(0, 8))
        self._pause_btn.configure(state="disabled")

        self._stop_btn = btn(ctrl_row, "Stop & Save", command=self._on_stop_click, style="danger")
        self._stop_btn.pack(side="left")
        self._stop_btn.configure(state="disabled")

    # ------------------------------------------------------------------
    # Interaction
    # ------------------------------------------------------------------

    def _on_start_click(self) -> None:
        if self._state == "idle":
            self._on_start()
            self._set_state("running")

    def _on_pause_click(self) -> None:
        self._on_pause()
        new = "paused" if self._state == "running" else "running"
        self._set_state(new)

    def _on_stop_click(self) -> None:
        """Stop and trigger the save overlay via app_window."""
        self._on_stop()
        self._set_state("idle")
        self._ring.reset()

    def _set_state(self, state: str) -> None:
        self._state = state
        if state == "idle":
            self._start_btn.configure(state="normal",   text="Start")
            self._pause_btn.configure(state="disabled",  text="Pause")
            self._stop_btn.configure(state="disabled")
            self._hint.configure(text="Press Start to begin tracking your session.")
        elif state == "running":
            self._start_btn.configure(state="disabled", text="Running…")
            self._pause_btn.configure(state="normal",   text="Pause")
            self._stop_btn.configure(state="normal")
            self._hint.configure(text="Session is running. Stop & Save when you're done.")
        elif state == "paused":
            self._start_btn.configure(state="disabled", text="Paused")
            self._pause_btn.configure(state="normal",   text="Resume")
            self._stop_btn.configure(state="normal")
            self._hint.configure(text="Paused. Resume when ready, or Stop & Save.")

    # ------------------------------------------------------------------
    # Called by app_window from event queue
    # ------------------------------------------------------------------

    def on_tick(self, elapsed: float, paused: bool) -> None:
        self._ring.update_stopwatch(elapsed, paused)

    def on_finish(self) -> None:
        """Not typically called for stopwatch, but reset if needed."""
        self._set_state("idle")
        self._ring.reset()
