"""
Main application window — the central hub of Project Remainder.

Responsibilities:
  • Creates and lays out the sidebar + content area
  • Manages navigation between views
  • Polls the timer event queue every 100 ms (thread-safe)
  • Routes timer ticks / finish events to the active view
  • Spawns the session-review overlay when a session ends
  • Saves / restores window geometry
  • Handles session recovery on startup
"""
from __future__ import annotations

import queue
import time
import tkinter as tk
from tkinter import messagebox
from typing import TYPE_CHECKING

from .theme import (
    ACCENT, ACCENT_HV, BG, BORDER, CARD, CARD_HOVER,
    FONT_BODY, FONT_BODY_B, FONT_H1, FONT_H2, FONT_H3,
    FONT_SMALL, PAD, PAD_LG, SIDEBAR_W, SURFACE, TEXT, TEXT_MUT,
)
from .dashboard_view import DashboardView
from .timer_view import TimerView
from .stopwatch_view import StopwatchView
from .stats_view import StatsView
from .todo_view import TodoView
from .settings_view import SettingsView
from .overlay_window import OverlayWindow

if TYPE_CHECKING:
    from ..core.timer_engine import TimerEngine
    from ..core.session_manager import SessionManager
    from ..core.settings_manager import SettingsManager
    from ..core.todo_manager import TodoManager


# Nav item: (key, display_text, icon_char)
_NAV = [
    ("dashboard",  "Dashboard",   "◈"),
    ("timer",      "Timer",       "◷"),
    ("stopwatch",  "Stopwatch",   "◶"),
    ("stats",      "Statistics",  "▤"),
    ("todo",       "To-Do List",  "☑"),
    ("settings",   "Settings",    "⚙"),
]


class AppWindow:
    """Wraps the root Tk window and manages the full application UI."""

    def __init__(
        self,
        root: tk.Tk,
        timer_engine: "TimerEngine",
        session_mgr: "SessionManager",
        settings_mgr: "SettingsManager",
        todo_mgr: "TodoManager",
    ) -> None:
        self.root = root
        self._timer = timer_engine
        self._sessions = session_mgr
        self._settings = settings_mgr
        self._todos = todo_mgr
        self._eq: "queue.Queue" = timer_engine.event_queue

        # Session tracking (for overlay)
        self._active_mode: str | None = None
        self._active_target: int | None = None
        self._session_start_time: str | None = None

        self._nav_indicators: dict[str, tk.Frame] = {}
        self._nav_labels: dict[str, tk.Label] = {}
        self._nav_frames: dict[str, tk.Frame] = {}
        self._current_nav = "dashboard"

        self._views: dict[str, tk.Frame] = {}
        self._overlay_open = False

        self._setup_root()
        self._apply_theme()
        self._build_layout()
        self._navigate("dashboard")
        self._poll_events()
        self._check_recovery()

    # ==================================================================
    # Window setup
    # ==================================================================

    def _setup_root(self) -> None:
        self.root.title("Project Remainder")
        self.root.configure(bg=BG)
        geo = self._settings.get("window_geometry", "960x680+80+60")
        try:
            self.root.geometry(geo)
        except Exception:
            self.root.geometry("960x680")
        self.root.minsize(780, 540)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _apply_theme(self) -> None:
        """Apply a global ttk style (affects scrollbars etc.)."""
        from tkinter import ttk
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("Vertical.TScrollbar",
                         background=SURFACE, troughcolor=BG,
                         bordercolor=BG, arrowcolor=TEXT_MUT)

    # ==================================================================
    # Layout
    # ==================================================================

    def _build_layout(self) -> None:
        # ── Root grid ─────────────────────────────────────────────────
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure(0, weight=1)

        # ── Sidebar ───────────────────────────────────────────────────
        sidebar = tk.Frame(self.root, bg=SURFACE, width=SIDEBAR_W)
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.grid_propagate(False)

        self._build_sidebar(sidebar)

        # ── Content area ──────────────────────────────────────────────
        content = tk.Frame(self.root, bg=BG)
        content.grid(row=0, column=1, sticky="nsew")
        content.rowconfigure(0, weight=1)
        content.columnconfigure(0, weight=1)
        self._content = content

        self._build_views(content)

    def _build_sidebar(self, parent: tk.Frame) -> None:
        # Logo
        logo = tk.Frame(parent, bg=SURFACE, pady=20)
        logo.pack(fill="x")
        tk.Label(logo, text="⏰", font=("Segoe UI", 28), bg=SURFACE, fg=ACCENT).pack()
        tk.Label(logo, text="Project", font=FONT_H2, bg=SURFACE, fg=TEXT).pack()
        tk.Label(logo, text="Remainder", font=FONT_SMALL, bg=SURFACE, fg=ACCENT).pack()

        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x")

        # Nav items
        todo_enabled = self._settings.get("todo_enabled", True)
        for key, label, icon in _NAV:
            if key == "todo" and not todo_enabled:
                continue
            self._build_nav_item(parent, key, label, icon)

    def _build_nav_item(self, parent: tk.Frame, key: str, label: str, icon: str) -> None:
        # Container row
        outer = tk.Frame(parent, bg=SURFACE, cursor="hand2")
        outer.pack(fill="x")

        # Coloured left-border indicator (3 px)
        indicator = tk.Frame(outer, width=3, bg=SURFACE)
        indicator.pack(side="left", fill="y")
        self._nav_indicators[key] = indicator

        # Icon + label
        inner = tk.Frame(outer, bg=SURFACE)
        inner.pack(side="left", fill="x", expand=True)

        row = tk.Frame(inner, bg=SURFACE)
        row.pack(fill="x")

        icon_lbl = tk.Label(row, text=icon, font=("Segoe UI", 12),
                            bg=SURFACE, fg=TEXT_MUT, width=2)
        icon_lbl.pack(side="left", padx=(10, 4), pady=10)

        text_lbl = tk.Label(row, text=label, font=FONT_BODY,
                            bg=SURFACE, fg=TEXT_MUT, anchor="w")
        text_lbl.pack(side="left", pady=10)
        self._nav_labels[key] = text_lbl
        self._nav_frames[key] = outer

        # Bindings on all sub-widgets
        for w in (outer, inner, row, icon_lbl, text_lbl):
            w.bind("<Button-1>", lambda e, k=key: self._navigate(k))
            w.bind("<Enter>",    lambda e, k=key: self._nav_hover(k, True))
            w.bind("<Leave>",    lambda e, k=key: self._nav_hover(k, False))

    def _build_views(self, parent: tk.Frame) -> None:
        def_mins = self._settings.get("default_timer_minutes", 25)

        self._dash_view = DashboardView(
            parent,
            session_mgr=self._sessions,
            on_start_timer=self._quick_start_timer,
            on_start_stopwatch=self._quick_start_stopwatch,
        )
        self._timer_view = TimerView(
            parent,
            on_start=self._start_timer,
            on_pause=self._pause_timer,
            on_stop=self._stop_timer,
            default_minutes=def_mins,
        )
        self._sw_view = StopwatchView(
            parent,
            on_start=self._start_stopwatch,
            on_pause=self._pause_timer,
            on_stop=self._stop_stopwatch_and_save,
        )
        self._stats_view = StatsView(parent, session_mgr=self._sessions)

        self._todo_view = TodoView(parent, todo_mgr=self._todos)

        self._settings_view = SettingsView(
            parent,
            settings_mgr=self._settings,
            on_todo_toggled=self._on_todo_toggled,
            on_timer_default_changed=self._on_timer_default_changed,
        )

        view_map: dict[str, tk.Frame] = {
            "dashboard": self._dash_view,
            "timer":     self._timer_view,
            "stopwatch": self._sw_view,
            "stats":     self._stats_view,
            "todo":      self._todo_view,
            "settings":  self._settings_view,
        }
        for v in view_map.values():
            v.grid(row=0, column=0, sticky="nsew")
        self._views = view_map

    # ==================================================================
    # Navigation
    # ==================================================================

    def _navigate(self, key: str) -> None:
        if key not in self._views:
            return
        # Deactivate current
        self._nav_deactivate(self._current_nav)
        # Activate new
        self._current_nav = key
        self._nav_activate(key)
        # Raise view
        self._views[key].tkraise()

    def _nav_activate(self, key: str) -> None:
        if key in self._nav_indicators:
            self._nav_indicators[key].configure(bg=ACCENT)
        if key in self._nav_labels:
            self._nav_labels[key].configure(fg=TEXT)
        if key in self._nav_frames:
            self._nav_frames[key].configure(bg=CARD)
            for w in self._nav_frames[key].winfo_children():
                self._set_bg_recursive(w, CARD)

    def _nav_deactivate(self, key: str) -> None:
        if key in self._nav_indicators:
            self._nav_indicators[key].configure(bg=SURFACE)
        if key in self._nav_labels:
            self._nav_labels[key].configure(fg=TEXT_MUT)
        if key in self._nav_frames:
            self._nav_frames[key].configure(bg=SURFACE)
            for w in self._nav_frames[key].winfo_children():
                self._set_bg_recursive(w, SURFACE)

    def _nav_hover(self, key: str, entering: bool) -> None:
        if key == self._current_nav:
            return
        color = CARD_HOVER if entering else SURFACE
        if key in self._nav_frames:
            self._nav_frames[key].configure(bg=color)
            for w in self._nav_frames[key].winfo_children():
                self._set_bg_recursive(w, color)

    def _set_bg_recursive(self, widget: tk.Widget, color: str) -> None:
        try:
            widget.configure(bg=color)
        except tk.TclError:
            pass
        for child in widget.winfo_children():
            self._set_bg_recursive(child, color)

    # ==================================================================
    # Timer / Stopwatch control
    # ==================================================================

    def _start_timer(self, seconds: int) -> None:
        self._active_mode = "timer"
        self._active_target = seconds
        self._session_start_time = time.strftime("%H:%M:%S")
        self._save_active_session()
        self._timer.start_timer(seconds, on_checkpoint=self._checkpoint)

    def _quick_start_timer(self, seconds: int) -> None:
        self._navigate("timer")
        self._timer_view.set_default_minutes(seconds // 60)
        self._start_timer(seconds)
        self._timer_view._set_state("running")

    def _quick_start_stopwatch(self) -> None:
        self._navigate("stopwatch")
        self._start_stopwatch()
        self._sw_view._set_state("running")

    def _start_stopwatch(self) -> None:
        self._active_mode = "stopwatch"
        self._active_target = None
        self._session_start_time = time.strftime("%H:%M:%S")
        self._save_active_session()
        self._timer.start_stopwatch(on_checkpoint=self._checkpoint)

    def _pause_timer(self) -> None:
        self._timer.toggle_pause()

    def _stop_timer(self) -> None:
        self._timer.stop()
        self._active_mode = None
        self._active_target = None
        self._session_start_time = None
        self._clear_active_session()

    def _stop_stopwatch_and_save(self) -> None:
        """Stop the stopwatch and immediately open the session review overlay."""
        state = self._timer.get_state()
        elapsed = state["elapsed_seconds"]
        start = self._session_start_time or time.strftime("%H:%M:%S")
        self._timer.stop()
        self._clear_active_session()
        # Open overlay manually (stopwatch 'finish' comes from user, not timer)
        if not self._overlay_open and elapsed >= 10:
            self._open_overlay("stopwatch", elapsed, start, None)
        self._active_mode = None
        self._active_target = None
        self._session_start_time = None

    # ==================================================================
    # Event queue polling (100 ms tick)
    # ==================================================================

    def _poll_events(self) -> None:
        try:
            while True:
                event = self._eq.get_nowait()
                self._handle_event(event)
        except queue.Empty:
            pass
        self.root.after(100, self._poll_events)

    def _handle_event(self, event: dict) -> None:
        etype = event.get("type")
        elapsed = event.get("elapsed", 0.0)
        total   = event.get("total", 0.0)
        mode    = event.get("mode", "")
        paused  = event.get("paused", False)

        if etype == "tick":
            if mode == "timer":
                self._timer_view.on_tick(elapsed, total, paused)
            elif mode == "stopwatch":
                self._sw_view.on_tick(elapsed, paused)

        elif etype == "finish":
            # Timer reached zero — show overlay
            self._timer_view.on_finish()
            start = self._session_start_time or time.strftime("%H:%M:%S")
            target = self._active_target
            self._clear_active_session()
            self._active_mode = None
            self._active_target = None
            self._session_start_time = None
            if not self._overlay_open:
                self.root.after(200, lambda: self._open_overlay("timer", elapsed, start, target))

    # ==================================================================
    # Overlay
    # ==================================================================

    def _open_overlay(
        self,
        mode: str,
        elapsed: float,
        start_time: str,
        target: int | None,
    ) -> None:
        if self._overlay_open:
            return
        self._overlay_open = True
        todo_enabled = self._settings.get("todo_enabled", True)

        OverlayWindow(
            self.root,
            mode=mode,
            elapsed=elapsed,
            start_time=start_time,
            target=target,
            todo_enabled=todo_enabled,
            todo_manager=self._todos if todo_enabled else None,
            session_mgr=self._sessions,
            settings_mgr=self._settings,
            on_done=self._on_session_saved,
        )

    def _on_session_saved(self, session: dict) -> None:
        self._overlay_open = False
        # Refresh views that show session data
        self._dash_view.refresh()
        self._stats_view.refresh()
        if self._settings.get("todo_enabled", True):
            self._todo_view.refresh()

    # ==================================================================
    # Settings callbacks
    # ==================================================================

    def _on_todo_toggled(self, enabled: bool) -> None:
        """Show or hide the To-Do nav item and view."""
        sidebar_parent = list(self.root.winfo_children())[0]  # sidebar frame
        if enabled:
            if "todo" not in self._nav_frames:
                # Re-add nav item — simplest: rebuild sidebar
                self._rebuild_sidebar()
        else:
            # Hide nav item
            if "todo" in self._nav_frames:
                self._nav_frames["todo"].pack_forget()
                del self._nav_frames["todo"]
                del self._nav_indicators["todo"]
                del self._nav_labels["todo"]
            if self._current_nav == "todo":
                self._navigate("dashboard")

    def _on_timer_default_changed(self, minutes: int) -> None:
        self._timer_view.set_default_minutes(minutes)

    def _rebuild_sidebar(self) -> None:
        """Rebuild the sidebar (used when re-enabling todo nav item)."""
        for f in self.root.winfo_children():
            if isinstance(f, tk.Frame) and f.cget("bg") == SURFACE:
                # This is the sidebar
                for w in f.winfo_children():
                    w.destroy()
                self._nav_indicators.clear()
                self._nav_labels.clear()
                self._nav_frames.clear()
                self._build_sidebar(f)
                self._nav_activate(self._current_nav)
                break

    # ==================================================================
    # Session persistence / recovery
    # ==================================================================

    def _checkpoint(self, state: dict) -> None:
        """Called by timer thread every 5 s to persist recoverable state."""
        if not state.get("is_running"):
            return
        self._settings.set("active_session", {
            "mode": self._active_mode,
            "elapsed_seconds": state["elapsed_seconds"],
            "total_seconds": state["total_seconds"],
            "session_start_time": self._session_start_time,
            "checkpoint_wall": time.strftime("%Y-%m-%dT%H:%M:%S"),
        })

    def _save_active_session(self) -> None:
        self._settings.set("active_session", {
            "mode": self._active_mode,
            "elapsed_seconds": 0,
            "total_seconds": self._active_target or 0,
            "session_start_time": self._session_start_time,
            "checkpoint_wall": time.strftime("%Y-%m-%dT%H:%M:%S"),
        })

    def _clear_active_session(self) -> None:
        self._settings.set("active_session", None)

    def _check_recovery(self) -> None:
        """On startup, offer to recover an interrupted session."""
        saved = self._settings.get("active_session")
        if not saved or not isinstance(saved, dict):
            return
        elapsed = saved.get("elapsed_seconds", 0)
        if elapsed < 10:
            self._clear_active_session()
            return
        mode = saved.get("mode", "unknown")
        from ..core.stats_engine import fmt_duration
        dur = fmt_duration(elapsed)
        answer = messagebox.askyesno(
            "Session Recovery",
            f"A previous {mode} session ({dur} elapsed) was interrupted.\n\n"
            "Would you like to save it now?",
            parent=self.root,
        )
        if answer:
            start = saved.get("session_start_time", time.strftime("%H:%M:%S"))
            self._sessions.save_session(
                mode=mode,
                start_time=start,
                end_time=time.strftime("%H:%M:%S"),
                duration_seconds=elapsed,
                target_duration=saved.get("total_seconds") or None,
                productivity_rating=3,
                notes="[Recovered session — timer was interrupted]",
            )
            self._dash_view.refresh()
            self._stats_view.refresh()
        self._clear_active_session()

    # ==================================================================
    # Window close
    # ==================================================================

    def _on_close(self) -> None:
        # Save geometry
        try:
            self._settings.set("window_geometry", self.root.geometry())
        except Exception:
            pass

        # Warn if timer is running
        state = self._timer.get_state()
        if state.get("is_running"):
            mode = state.get("mode", "session")
            answer = messagebox.askyesno(
                "Timer Running",
                f"A {mode} is still running.\n\n"
                "Close anyway? The current session state is saved and "
                "you'll be offered to recover it next time.",
                parent=self.root,
            )
            if not answer:
                return

        self._timer.stop()
        self.root.destroy()
