"""
Project Remainder — visual design constants.

Brand color: #228822 (forest green)
Theme: Dark, calm, focused.
Typography: Segoe UI (Windows built-in, excellent legibility)
"""

# ── Colour palette ─────────────────────────────────────────────────────────
BG          = "#0d1117"   # Main window background
SURFACE     = "#161b22"   # Sidebar / secondary panels
CARD        = "#21262d"   # Card / widget backgrounds
CARD_HOVER  = "#2d333b"   # Card hover state
CARD_SEL    = "#1f3a1f"   # Selected card (green tint)
ACCENT      = "#228822"   # Primary brand green
ACCENT_HV   = "#2da52d"   # Accent on hover
ACCENT_DIM  = "#1a6b1a"   # Dimmed accent (button inactive)
TEXT        = "#e6edf3"   # Primary text
TEXT_MUT    = "#7d8590"   # Muted / label text
TEXT_HINT   = "#484f58"   # Very muted hint text
BORDER      = "#30363d"   # Borders and separators
BORDER_LT   = "#3d444d"   # Light border (inputs)
WARN        = "#d29922"   # Warning / amber
DANGER      = "#f85149"   # Error / red
SUCCESS     = "#3fb950"   # Success / bright green

# Timer progress ring colours
RING_BG     = "#21262d"
RING_FG     = "#228822"
RING_WARN   = "#d29922"   # < 20% remaining
RING_CRIT   = "#f85149"   # < 10% remaining

# Star rating
STAR_ON     = "#d29922"   # Filled star
STAR_OFF    = "#30363d"   # Empty star

# ── Font definitions (Segoe UI — ships with Windows) ───────────────────────
_F = "Segoe UI"
_M = "Courier New"

FONT_H1         = (_F, 20, "bold")
FONT_H2         = (_F, 15, "bold")
FONT_H3         = (_F, 12, "bold")
FONT_BODY       = (_F, 11)
FONT_BODY_B     = (_F, 11, "bold")
FONT_SMALL      = (_F, 9)
FONT_TINY       = (_F, 8)
FONT_MONO       = (_M, 11)

FONT_TIMER_XL   = (_F, 54, "bold")
FONT_TIMER_LG   = (_F, 40, "bold")
FONT_TIMER_MD   = (_F, 28, "bold")
FONT_TIMER_SM   = (_F, 18, "bold")

# ── Layout metrics ─────────────────────────────────────────────────────────
SIDEBAR_W   = 190    # px, fixed sidebar width
PAD         = 12     # standard padding
PAD_LG      = 20     # large padding
PAD_SM      = 6      # small padding
BTN_H       = 38     # button height
RADIUS      = 6      # corner radius for drawn elements
