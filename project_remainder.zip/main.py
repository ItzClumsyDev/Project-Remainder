"""
Project Remainder — Main Entry Point

A lightweight, open-source work-session timer and productivity tracker.
"""
from __future__ import annotations

import queue
import sys
import tkinter as tk

from app.core.session_manager import SessionManager
from app.core.settings_manager import SettingsManager
from app.core.timer_engine import TimerEngine
from app.core.todo_manager import TodoManager
from app.ui.app_window import AppWindow


def main() -> None:
    root = tk.Tk()

    # Communication queue between timer engine thread and tkinter main thread
    event_queue: queue.Queue = queue.Queue(maxsize=100)

    # Initialize core managers
    timer_engine = TimerEngine(event_queue=event_queue)
    session_mgr = SessionManager()
    settings_mgr = SettingsManager()
    todo_mgr = TodoManager()

    # Initialize UI
    _app = AppWindow(
        root=root,
        timer_engine=timer_engine,
        session_mgr=session_mgr,
        settings_mgr=settings_mgr,
        todo_mgr=todo_mgr,
    )

    # Start Tkinter event loop
    try:
        root.mainloop()
    except KeyboardInterrupt:
        timer_engine.stop()
        sys.exit(0)


if __name__ == "__main__":
    main()
